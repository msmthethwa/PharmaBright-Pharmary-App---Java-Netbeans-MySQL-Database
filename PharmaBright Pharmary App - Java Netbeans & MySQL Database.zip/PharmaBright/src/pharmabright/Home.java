/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package pharmabright;

import java.awt.print.PrinterException; // For handling printing-related exceptions
import java.text.DecimalFormat; // For formatting decimal numbers
import java.text.SimpleDateFormat; // For formatting dates
import java.util.ArrayList; // For using ArrayList collection
import java.util.Date; // For working with date objects
import java.util.List; // For using List interface
import javax.swing.JFrame; // For creating JFrame windows
import javax.swing.JOptionPane; // For displaying dialog boxes
import javax.swing.table.DefaultTableModel; // For working with table models in JTable
import java.sql.PreparedStatement; // For executing SQL statements
import java.sql.ResultSet; // For handling SQL query results
import java.sql.DriverManager; // For managing database drivers

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

import java.awt.Image;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Properties;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;

/**
 *
 * @author MS Mthethwa
 */
public class Home extends javax.swing.JFrame {

    /**
     * Creates new form Home
     */
    
    public    Connection con = null;
    public    PreparedStatement pst = null;
    public    ResultSet rs = null;
    
    public String url = "jdbc:mysql://localhost:3306/PharmaBright?zeroDateTimeBehavior=CONVERT_TO_NULL";   
    
    
    public Home() {
        // Initialize components and maximize the JFrame window
        initComponents();
        this.setExtendedState(JFrame.MAXIMIZED_BOTH);

        // Set preferred width for the first two columns in jTable1
        jTable1.getColumnModel().getColumn(0).setPreferredWidth(30);
        jTable1.getColumnModel().getColumn(1).setPreferredWidth(200);
        
        // Set the bill panel and the bill component to be initially invisible
        billPanel.setVisible(false);
        bill.setVisible(false);
        
        // Set all the quantity labels (q1 to q20) to be initially invisible
        q1.setVisible(false);
        q2.setVisible(false);
        q3.setVisible(false);
        q4.setVisible(false);
        q5.setVisible(false);
        q6.setVisible(false);
        q7.setVisible(false);
        q8.setVisible(false);
        q9.setVisible(false);
        q10.setVisible(false);
        q11.setVisible(false);
        q12.setVisible(false);
        q13.setVisible(false);
        q14.setVisible(false);
        q15.setVisible(false);
        q16.setVisible(false);
        q17.setVisible(false);
        q18.setVisible(false);
        q19.setVisible(false);
        q20.setVisible(false);
        
        // Initialize product images
        initializeProductImages();
    }
    
    // Method to retrieve image from database and set it to JButton
    public void setProductImage(JButton button, int productId) { 
        try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish connection to the database
            con = DriverManager.getConnection(url, "root", "Admin#01");

            // Prepare SQL query to retrieve image for the given product ID
            String query = "SELECT image FROM Products WHERE Id = ?";
            pst = con.prepareStatement(query);
            pst.setInt(1, productId);

            // Execute the query
            rs = pst.executeQuery();

            if (rs.next()) {
                // Retrieve the image as a Blob
                Blob blob = rs.getBlob("image");

                if (blob != null) {
                    // Convert Blob to InputStream
                    InputStream is = blob.getBinaryStream();

                    // Create an ImageIcon from the InputStream
                    ImageIcon imageIcon = new ImageIcon(blob.getBytes(1, (int) blob.length()));

                    // Optionally scale the image if needed
                    Image img = imageIcon.getImage().getScaledInstance(button.getWidth(), button.getHeight(), Image.SCALE_SMOOTH);
                    button.setIcon(new ImageIcon(img));
                } else {
                    // If no image is found, set a default icon or clear the existing icon
                    button.setIcon(null);
                    setVisibility(productId, true);
                }
            } else {
                // If no product is found, set a default icon or clear the existing icon
                //button.setIcon(null);
                setVisibility(productId, true);
            }

        } catch (Exception e) {
            // Display any exceptions that occur
            JOptionPane.showMessageDialog(null, e);
        } finally {
            // Close resources to avoid memory leaks
            try {
                if (rs != null) rs.close();
                if (pst != null) pst.close();
                if (con != null) con.close();
            } catch (Exception e) {
                // Display any exceptions that occur
                JOptionPane.showMessageDialog(null, e);
            }
        }
    }

    // Method to set visibility of components based on productId when product or image is not available
    private void setVisibility(int productId, boolean visibility) {
        switch(productId) {
            case 1: q1.setVisible(visibility); q01.setVisible(!visibility); break;
            case 2: q2.setVisible(visibility); q02.setVisible(!visibility); break;
            case 3: q3.setVisible(visibility); q03.setVisible(!visibility); break;
            case 4: q4.setVisible(visibility); q04.setVisible(!visibility); break;
            case 5: q5.setVisible(visibility); q05.setVisible(!visibility); break;
            case 6: q6.setVisible(visibility); q06.setVisible(!visibility); break;
            case 7: q7.setVisible(visibility); q07.setVisible(!visibility); break;
            case 8: q8.setVisible(visibility); q08.setVisible(!visibility); break;
            case 9: q9.setVisible(visibility); q09.setVisible(!visibility); break;
            case 10: q10.setVisible(visibility); q010.setVisible(!visibility); break;
            case 11: q11.setVisible(visibility); q011.setVisible(!visibility); break;
            case 12: q12.setVisible(visibility); q012.setVisible(!visibility); break;
            case 13: q13.setVisible(visibility); q013.setVisible(!visibility); break;
            case 14: q14.setVisible(visibility); q014.setVisible(!visibility); break;
            case 15: q15.setVisible(visibility); q015.setVisible(!visibility); break;
            case 16: q16.setVisible(visibility); q016.setVisible(!visibility); break;
            case 17: q17.setVisible(visibility); q017.setVisible(!visibility); break;
            case 18: q18.setVisible(visibility); q018.setVisible(!visibility); break;
            case 19: q19.setVisible(visibility); q019.setVisible(!visibility); break;
            case 20: q20.setVisible(visibility); q020.setVisible(!visibility); break;
            default: break;
        }
    }

    // Call this method for each button in your initialization code
    public void initializeProductImages() {
        setProductImage(p1, 1);
        setProductImage(p2, 2);
        setProductImage(p3, 3);
        setProductImage(p4, 4);
        setProductImage(p5, 5);
        setProductImage(p6, 6);
        setProductImage(p7, 7);
        setProductImage(p8, 8);
        setProductImage(p9, 9);
        setProductImage(p10, 10);
        setProductImage(p11, 11);
        setProductImage(p12, 12);
        setProductImage(p13, 13);
        setProductImage(p14, 14);
        setProductImage(p15, 15);
        setProductImage(p16, 16);
        setProductImage(p17, 17);
        setProductImage(p18, 18);
        setProductImage(p19, 19);
        setProductImage(p20, 20);
    }
    
    public void addtable(int id, String name, int qty, double price) {
        // Get the table model from jTable1
        DefaultTableModel dt = (DefaultTableModel) jTable1.getModel();

        // Create an ArrayList to store the row data
        List<Object> row = new ArrayList<>();
        row.add(id);
        row.add(name);
        row.add(qty);
        row.add(price);

        // Add the row to the table model
        dt.addRow(row.toArray());
    }

    public void addtables(int id ,String Name,int Qty ,Double Price){
        // Get the table model from jTable1
        DefaultTableModel dt = (DefaultTableModel) jTable1.getModel();

        // Format the total price to two decimal places
        DecimalFormat df = new DecimalFormat("00.00");
        double totPrice = Price * Qty;
        String TotalPrice = df.format(totPrice);

        // Check if the product is already added and remove it if found
        for (int row = 0; row < jTable1.getRowCount(); row++) {
            if (Name.equals(jTable1.getValueAt(row, 1))) {
                dt.removeRow(jTable1.convertRowIndexToModel(row));
            }
        }

        // Create an ArrayList to store the row data
        List<Object> row = new ArrayList<>();
        row.add(id);
        row.add(Name);
        row.add(Qty);
        row.add(TotalPrice); // total price

        // Add the row to the table model
        dt.addRow(row.toArray());
    }
    
   public void cal(){
        // Calculate the total values in the table
        int numOfRow = jTable1.getRowCount();
        double tot = 0.0;

        for (int i = 0; i < numOfRow; i++) {
            double value = Double.valueOf(jTable1.getValueAt(i, 3).toString());
            tot += value;
        }

        // Format the total value to two decimal places and set it to the total field
        DecimalFormat df = new DecimalFormat("00.00");
        total.setText(df.format(tot));

        // Call the pay method to proceed with payment
        pay();
   } 
    
    public void Bill() {
        // bill print
        try {
            // Header
            bill.setText("****************************************************************************************************************\n");
            bill.setText(bill.getText() + "                                     PharmaBright Pharmacy\n");
            bill.setText(bill.getText() + "                          Shop 2, 44 Mackeurtan Avenue, Durban North\n");
            bill.setText(bill.getText() + "                       Kwa-Zulu Natal, 4001 | Tel: 031 108 0312\n");
            bill.setText(bill.getText() + "                   Email: contact@pharmabright.com | Website: www.pharmabright.com\n");
            bill.setText(bill.getText() + "                                     Date: " + new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(new Date()) + "\n");
            bill.setText(bill.getText() + "****************************************************************************************************************\n");

            // Table Headers
            bill.setText(bill.getText() + String.format("%-30s %-15s %-15s %-15s\n", "Item", "Quantity", "Unit Price", "Total Price"));
            bill.setText(bill.getText() + "--------------------------------------------------------------------------------------------------------------------------------------------------\n");

            DefaultTableModel df = (DefaultTableModel) jTable1.getModel();

            // Table Product details
            for (int i = 0; i < jTable1.getRowCount(); i++) {
                String name = df.getValueAt(i, 1).toString();
                String qty = df.getValueAt(i, 2).toString();
                String price = df.getValueAt(i, 3).toString();
                String totalPrice = String.valueOf(Integer.parseInt(qty) * Double.parseDouble(price));

                bill.setText(bill.getText() + String.format("%-30s %-15s %-15s %-15s\n", name, qty, price, totalPrice));
            }

            // Footer
            bill.setText(bill.getText() + "--------------------------------------------------------------------------------------------------------------------------------------------------\n");
            bill.setText(bill.getText() + String.format("%-30s %15s\n", "Sub Total:", total.getText()));
            bill.setText(bill.getText() + String.format("%-30s %15s\n", "Cash Paid:", payAmt.getText()));
            bill.setText(bill.getText() + String.format("%-30s %15s\n", "Balance:", bal.getText()));
            bill.setText(bill.getText() + "--------------------------------------------------------------------------------------------------------------------------------------------------\n");
            bill.setText(bill.getText() + "                           Thank You for Shopping with Us!\n");
            bill.setText(bill.getText() + "                             Visit us again at PharmaBright Pharmacy\n");
            bill.setText(bill.getText() + "--------------------------------------------------------------------------------------------------------------------------------------------------\n");
            bill.setText(bill.getText() + "                           Powered by MS Innovation\n");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e, "Error", JOptionPane.ERROR_MESSAGE);    
        } 
    }

    public void pay(){
        // Pay button action

        // Get the total amount and the amount paid from the respective text fields
        String totalText = total.getText();
        String payText = payAmt.getText();

        // Check if the pay field is empty or null
        if (payText == null || payText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter valid values Pay", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            // Convert the total and paid amounts from String to double
            double tot = Double.valueOf(totalText);
            double paid = Double.valueOf(payText);
            double balance = paid - tot; // Calculate the balance

            // Format the balance to two decimal places
            DecimalFormat df = new DecimalFormat("00.00");
            bal.setText(String.valueOf(df.format(balance))); // Set the formatted balance to the bal field

            // Call the Bill method to proceed with billing
            Bill();

        } catch (NumberFormatException e) {
            // Handle invalid number format
            JOptionPane.showMessageDialog(this, "Please enter valid values Pay", "Input Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void sendEmail(String to, String subject, String messageContent) {
        // Assuming you are sending email from through Gmail's SMTP
        String host = "smtp.gmail.com";
        final String user = ""; //company email address (From: )
        final String password = ""; // password from 2-Step Verification

        // Get the session object
        Properties props = new Properties();
        props.put("mail.smtp.host", host);
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.port", "587");
        props.put("mail.smtp.starttls.enable", "true");

        Session session = Session.getInstance(props,
            new javax.mail.Authenticator() {
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(user, password);
                }
            });

        // Compose the message
        try {
            MimeMessage message = new MimeMessage(session);
            message.setFrom(new InternetAddress(user));
            message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
            message.setSubject(subject);

            // Use MimeBodyPart and Multipart to support HTML content
            MimeBodyPart mimeBodyPart = new MimeBodyPart();
            mimeBodyPart.setContent(messageContent, "text/html");

            Multipart multipart = new MimeMultipart();
            multipart.addBodyPart(mimeBodyPart);

            message.setContent(multipart);

            // Send message
            Transport.send(message);
            System.out.println("Message sent successfully");

        } catch (MessagingException e) {
            throw new RuntimeException(e);
        }
    }
    
    public String generateBill() {
        StringBuilder billContent = new StringBuilder();

        try {
            // Header
            billContent.append("<h2>PharmaBright Pharmacy</h2>");
            billContent.append("<p>Shop 2, 44 Mackeurtan Avenue, Durban North<br>KZN, 4001 | Tel: 031 108 0312<br>");
            billContent.append("Email: contact@pharmabright.com | Website: www.pharmabright.com<br>");
            billContent.append("Date: ").append(new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(new Date())).append("</p>");
            billContent.append("<hr>");

            // Table Headers
            billContent.append("<table>");
            billContent.append("<tr><th>Item</th><th>Quantity</th><th>Unit Price</th><th>Total Price</th></tr>");

            DefaultTableModel df = (DefaultTableModel) jTable1.getModel();

            // Table Product details
            for (int i = 0; i < jTable1.getRowCount(); i++) {
                String name = df.getValueAt(i, 1).toString();
                String qty = df.getValueAt(i, 2).toString();
                String price = df.getValueAt(i, 3).toString();
                String totalPrice = String.valueOf(Integer.parseInt(qty) * Double.parseDouble(price));

                billContent.append("<tr><td>").append(name).append("</td><td>")
                           .append(qty).append("</td><td>").append(price)
                           .append("</td><td>").append(totalPrice).append("</td></tr>");
            }

            // Footer
            billContent.append("</table><hr>");
            billContent.append("<p>Sub Total: ").append(total.getText()).append("</p>");
            billContent.append("<p>Cash Paid: ").append(payAmt.getText()).append("</p>");
            billContent.append("<p>Balance: ").append(bal.getText()).append("</p>");
            billContent.append("<hr>");
            billContent.append("<p>Thank You for Shopping with Us!<br>Visit us again at PharmaBright Pharmacy</p>");
            billContent.append("<p>Powered by MS Innovation</p>");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e, "Error", JOptionPane.ERROR_MESSAGE);    
        }

        return billContent.toString();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel = new javax.swing.JPanel();
        displayPanel = new javax.swing.JPanel();
        bal = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        total = new javax.swing.JLabel();
        jButton21 = new javax.swing.JButton();
        payAmt = new javax.swing.JTextField();
        listPanel = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        itemsPanel = new javax.swing.JPanel();
        q1 = new javax.swing.JLabel();
        p1 = new javax.swing.JButton();
        q2 = new javax.swing.JLabel();
        p3 = new javax.swing.JButton();
        q3 = new javax.swing.JLabel();
        p4 = new javax.swing.JButton();
        q4 = new javax.swing.JLabel();
        p5 = new javax.swing.JButton();
        q5 = new javax.swing.JLabel();
        p6 = new javax.swing.JButton();
        q6 = new javax.swing.JLabel();
        p7 = new javax.swing.JButton();
        q7 = new javax.swing.JLabel();
        p8 = new javax.swing.JButton();
        q8 = new javax.swing.JLabel();
        p9 = new javax.swing.JButton();
        q9 = new javax.swing.JLabel();
        p10 = new javax.swing.JButton();
        q10 = new javax.swing.JLabel();
        q13 = new javax.swing.JLabel();
        p14 = new javax.swing.JButton();
        q14 = new javax.swing.JLabel();
        p11 = new javax.swing.JButton();
        q12 = new javax.swing.JLabel();
        p13 = new javax.swing.JButton();
        p15 = new javax.swing.JButton();
        q15 = new javax.swing.JLabel();
        p12 = new javax.swing.JButton();
        q11 = new javax.swing.JLabel();
        p18 = new javax.swing.JButton();
        q19 = new javax.swing.JLabel();
        p19 = new javax.swing.JButton();
        q20 = new javax.swing.JLabel();
        p17 = new javax.swing.JButton();
        q16 = new javax.swing.JLabel();
        q18 = new javax.swing.JLabel();
        q17 = new javax.swing.JLabel();
        p20 = new javax.swing.JButton();
        p16 = new javax.swing.JButton();
        backBtn = new javax.swing.JLabel();
        nextBtn = new javax.swing.JLabel();
        p2 = new javax.swing.JButton();
        q01 = new javax.swing.JLabel();
        q02 = new javax.swing.JLabel();
        q03 = new javax.swing.JLabel();
        q04 = new javax.swing.JLabel();
        q05 = new javax.swing.JLabel();
        q06 = new javax.swing.JLabel();
        q07 = new javax.swing.JLabel();
        q08 = new javax.swing.JLabel();
        q09 = new javax.swing.JLabel();
        q010 = new javax.swing.JLabel();
        q011 = new javax.swing.JLabel();
        q012 = new javax.swing.JLabel();
        q013 = new javax.swing.JLabel();
        q014 = new javax.swing.JLabel();
        q015 = new javax.swing.JLabel();
        q016 = new javax.swing.JLabel();
        q017 = new javax.swing.JLabel();
        q018 = new javax.swing.JLabel();
        q019 = new javax.swing.JLabel();
        q020 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        delete = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        billPanel = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        bill = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("PharmaBright");
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel.setOpaque(false);
        jPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        displayPanel.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        displayPanel.setOpaque(false);
        displayPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        bal.setFont(new java.awt.Font("Myanmar Text", 1, 20)); // NOI18N
        bal.setForeground(new java.awt.Color(0, 0, 0));
        bal.setText("00");
        displayPanel.add(bal, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 100, 120, 40));

        jLabel24.setFont(new java.awt.Font("Myanmar Text", 1, 20)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(0, 0, 0));
        jLabel24.setText("Pay:");
        displayPanel.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 70, 40));

        jLabel23.setFont(new java.awt.Font("Myanmar Text", 1, 20)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(0, 0, 0));
        jLabel23.setText("Total:");
        displayPanel.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 70, 40));

        jLabel25.setFont(new java.awt.Font("Myanmar Text", 1, 20)); // NOI18N
        jLabel25.setForeground(new java.awt.Color(0, 0, 0));
        jLabel25.setText("Balance:");
        displayPanel.add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 100, 90, 40));

        total.setFont(new java.awt.Font("Myanmar Text", 1, 20)); // NOI18N
        total.setForeground(new java.awt.Color(0, 0, 0));
        total.setText("00");
        displayPanel.add(total, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 20, 120, 40));

        jButton21.setBackground(new java.awt.Color(0, 153, 153));
        jButton21.setFont(new java.awt.Font("Myanmar Text", 3, 24)); // NOI18N
        jButton21.setForeground(new java.awt.Color(255, 255, 255));
        jButton21.setText("PAY");
        jButton21.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton21.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton21.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton21ActionPerformed(evt);
            }
        });
        displayPanel.add(jButton21, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 50, 90, 60));

        payAmt.setBackground(new java.awt.Color(255, 255, 204));
        payAmt.setFont(new java.awt.Font("Myanmar Text", 1, 18)); // NOI18N
        payAmt.setForeground(new java.awt.Color(0, 0, 0));
        payAmt.setText("0");
        payAmt.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 153, 255), 3));
        payAmt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                payAmtKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                payAmtKeyTyped(evt);
            }
        });
        displayPanel.add(payAmt, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 60, 180, 40));

        jPanel.add(displayPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 520, 450, 160));

        listPanel.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        listPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Product", "Quantity", "Price"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        listPanel.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 520, 410));

        jPanel.add(listPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 10, 520, 410));

        itemsPanel.setBackground(new java.awt.Color(255, 255, 255));
        itemsPanel.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        itemsPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        q1.setFont(new java.awt.Font("Myanmar Text", 1, 24)); // NOI18N
        q1.setForeground(new java.awt.Color(153, 153, 153));
        q1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        q1.setText("0");
        itemsPanel.add(q1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 140, 100, 40));

        p1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/error_404.jpg"))); // NOI18N
        p1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p1ActionPerformed(evt);
            }
        });
        itemsPanel.add(p1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 40, 100, 100));

        q2.setFont(new java.awt.Font("Myanmar Text", 1, 24)); // NOI18N
        q2.setForeground(new java.awt.Color(153, 153, 153));
        q2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        q2.setText("0");
        itemsPanel.add(q2, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 140, 100, 40));

        p3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/error_404.jpg"))); // NOI18N
        p3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p3ActionPerformed(evt);
            }
        });
        itemsPanel.add(p3, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 40, 100, 100));

        q3.setFont(new java.awt.Font("Myanmar Text", 1, 24)); // NOI18N
        q3.setForeground(new java.awt.Color(153, 153, 153));
        q3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        q3.setText("0");
        itemsPanel.add(q3, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 140, 100, 40));

        p4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/error_404.jpg"))); // NOI18N
        p4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p4ActionPerformed(evt);
            }
        });
        itemsPanel.add(p4, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 40, 100, 100));

        q4.setFont(new java.awt.Font("Myanmar Text", 1, 24)); // NOI18N
        q4.setForeground(new java.awt.Color(153, 153, 153));
        q4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        q4.setText("0");
        itemsPanel.add(q4, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 140, 100, 40));

        p5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/error_404.jpg"))); // NOI18N
        p5.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p5ActionPerformed(evt);
            }
        });
        itemsPanel.add(p5, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 40, 100, 100));

        q5.setFont(new java.awt.Font("Myanmar Text", 1, 24)); // NOI18N
        q5.setForeground(new java.awt.Color(153, 153, 153));
        q5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        q5.setText("0");
        itemsPanel.add(q5, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 140, 100, 40));

        p6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/error_404.jpg"))); // NOI18N
        p6.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p6ActionPerformed(evt);
            }
        });
        itemsPanel.add(p6, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 190, 100, 100));

        q6.setFont(new java.awt.Font("Myanmar Text", 1, 24)); // NOI18N
        q6.setForeground(new java.awt.Color(153, 153, 153));
        q6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        q6.setText("0");
        itemsPanel.add(q6, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 290, 100, 40));

        p7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/error_404.jpg"))); // NOI18N
        p7.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p7ActionPerformed(evt);
            }
        });
        itemsPanel.add(p7, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 190, 100, 100));

        q7.setFont(new java.awt.Font("Myanmar Text", 1, 24)); // NOI18N
        q7.setForeground(new java.awt.Color(153, 153, 153));
        q7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        q7.setText("0");
        itemsPanel.add(q7, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 290, 100, 40));

        p8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/error_404.jpg"))); // NOI18N
        p8.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p8ActionPerformed(evt);
            }
        });
        itemsPanel.add(p8, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 190, 100, 100));

        q8.setFont(new java.awt.Font("Myanmar Text", 1, 24)); // NOI18N
        q8.setForeground(new java.awt.Color(153, 153, 153));
        q8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        q8.setText("0");
        itemsPanel.add(q8, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 290, 100, 40));

        p9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/error_404.jpg"))); // NOI18N
        p9.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p9ActionPerformed(evt);
            }
        });
        itemsPanel.add(p9, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 190, 100, 100));

        q9.setFont(new java.awt.Font("Myanmar Text", 1, 24)); // NOI18N
        q9.setForeground(new java.awt.Color(153, 153, 153));
        q9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        q9.setText("0");
        itemsPanel.add(q9, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 290, 100, 40));

        p10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/error_404.jpg"))); // NOI18N
        p10.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p10ActionPerformed(evt);
            }
        });
        itemsPanel.add(p10, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 190, 100, 100));

        q10.setFont(new java.awt.Font("Myanmar Text", 1, 24)); // NOI18N
        q10.setForeground(new java.awt.Color(153, 153, 153));
        q10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        q10.setText("0");
        itemsPanel.add(q10, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 290, 100, 40));

        q13.setFont(new java.awt.Font("Myanmar Text", 1, 24)); // NOI18N
        q13.setForeground(new java.awt.Color(153, 153, 153));
        q13.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        q13.setText("0");
        itemsPanel.add(q13, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 450, 100, 40));

        p14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/error_404.jpg"))); // NOI18N
        p14.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p14ActionPerformed(evt);
            }
        });
        itemsPanel.add(p14, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 350, 100, 100));

        q14.setFont(new java.awt.Font("Myanmar Text", 1, 24)); // NOI18N
        q14.setForeground(new java.awt.Color(153, 153, 153));
        q14.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        q14.setText("0");
        itemsPanel.add(q14, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 450, 100, 40));

        p11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/error_404.jpg"))); // NOI18N
        p11.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p11ActionPerformed(evt);
            }
        });
        itemsPanel.add(p11, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 350, 100, 100));

        q12.setFont(new java.awt.Font("Myanmar Text", 1, 24)); // NOI18N
        q12.setForeground(new java.awt.Color(153, 153, 153));
        q12.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        q12.setText("0");
        itemsPanel.add(q12, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 450, 100, 40));

        p13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/error_404.jpg"))); // NOI18N
        p13.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p13ActionPerformed(evt);
            }
        });
        itemsPanel.add(p13, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 350, 100, 100));

        p15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/error_404.jpg"))); // NOI18N
        p15.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p15ActionPerformed(evt);
            }
        });
        itemsPanel.add(p15, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 350, 100, 100));

        q15.setFont(new java.awt.Font("Myanmar Text", 1, 24)); // NOI18N
        q15.setForeground(new java.awt.Color(153, 153, 153));
        q15.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        q15.setText("0");
        itemsPanel.add(q15, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 450, 100, 40));

        p12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/error_404.jpg"))); // NOI18N
        p12.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p12ActionPerformed(evt);
            }
        });
        itemsPanel.add(p12, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 350, 100, 100));

        q11.setFont(new java.awt.Font("Myanmar Text", 1, 24)); // NOI18N
        q11.setForeground(new java.awt.Color(153, 153, 153));
        q11.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        q11.setText("0");
        itemsPanel.add(q11, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 450, 100, 40));

        p18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/error_404.jpg"))); // NOI18N
        p18.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p18.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p18ActionPerformed(evt);
            }
        });
        itemsPanel.add(p18, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 500, 100, 100));

        q19.setFont(new java.awt.Font("Myanmar Text", 1, 24)); // NOI18N
        q19.setForeground(new java.awt.Color(153, 153, 153));
        q19.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        q19.setText("0");
        itemsPanel.add(q19, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 600, 100, 40));

        p19.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/error_404.jpg"))); // NOI18N
        p19.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p19.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p19ActionPerformed(evt);
            }
        });
        itemsPanel.add(p19, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 500, 100, 100));

        q20.setFont(new java.awt.Font("Myanmar Text", 1, 24)); // NOI18N
        q20.setForeground(new java.awt.Color(153, 153, 153));
        q20.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        q20.setText("0");
        itemsPanel.add(q20, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 600, 100, 40));

        p17.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/error_404.jpg"))); // NOI18N
        p17.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p17.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p17ActionPerformed(evt);
            }
        });
        itemsPanel.add(p17, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 500, 100, 100));

        q16.setFont(new java.awt.Font("Myanmar Text", 1, 24)); // NOI18N
        q16.setForeground(new java.awt.Color(153, 153, 153));
        q16.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        q16.setText("0");
        itemsPanel.add(q16, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 600, 100, 40));

        q18.setFont(new java.awt.Font("Myanmar Text", 1, 24)); // NOI18N
        q18.setForeground(new java.awt.Color(153, 153, 153));
        q18.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        q18.setText("0");
        itemsPanel.add(q18, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 600, 100, 40));

        q17.setFont(new java.awt.Font("Myanmar Text", 1, 24)); // NOI18N
        q17.setForeground(new java.awt.Color(153, 153, 153));
        q17.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        q17.setText("0");
        itemsPanel.add(q17, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 600, 100, 40));

        p20.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/error_404.jpg"))); // NOI18N
        p20.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p20.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p20ActionPerformed(evt);
            }
        });
        itemsPanel.add(p20, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 500, 100, 100));

        p16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/error_404.jpg"))); // NOI18N
        p16.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p16ActionPerformed(evt);
            }
        });
        itemsPanel.add(p16, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 500, 100, 100));

        backBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/back-button.png"))); // NOI18N
        itemsPanel.add(backBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 300, 40, 40));

        nextBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/next-button.png"))); // NOI18N
        itemsPanel.add(nextBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 300, 40, 40));

        p2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/error_404.jpg"))); // NOI18N
        p2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        p2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p2ActionPerformed(evt);
            }
        });
        itemsPanel.add(p2, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 40, 100, 100));

        q01.setFont(new java.awt.Font("Myanmar Text", 1, 24)); // NOI18N
        q01.setForeground(new java.awt.Color(153, 153, 153));
        q01.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        q01.setText("R219,95");
        itemsPanel.add(q01, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 140, 100, 40));

        q02.setFont(new java.awt.Font("Myanmar Text", 1, 24)); // NOI18N
        q02.setForeground(new java.awt.Color(153, 153, 153));
        q02.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        q02.setText("R189,95");
        itemsPanel.add(q02, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 140, 100, 40));

        q03.setFont(new java.awt.Font("Myanmar Text", 1, 24)); // NOI18N
        q03.setForeground(new java.awt.Color(153, 153, 153));
        q03.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        q03.setText("R204,95");
        itemsPanel.add(q03, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 140, 100, 40));

        q04.setFont(new java.awt.Font("Myanmar Text", 1, 24)); // NOI18N
        q04.setForeground(new java.awt.Color(153, 153, 153));
        q04.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        q04.setText("R197,95");
        itemsPanel.add(q04, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 140, 100, 40));

        q05.setFont(new java.awt.Font("Myanmar Text", 1, 24)); // NOI18N
        q05.setForeground(new java.awt.Color(153, 153, 153));
        q05.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        q05.setText("R94,96");
        itemsPanel.add(q05, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 140, 100, 40));

        q06.setFont(new java.awt.Font("Myanmar Text", 1, 24)); // NOI18N
        q06.setForeground(new java.awt.Color(153, 153, 153));
        q06.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        q06.setText("R119,95");
        itemsPanel.add(q06, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 290, 100, 40));

        q07.setFont(new java.awt.Font("Myanmar Text", 1, 24)); // NOI18N
        q07.setForeground(new java.awt.Color(153, 153, 153));
        q07.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        q07.setText("R189,95");
        itemsPanel.add(q07, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 290, 100, 40));

        q08.setFont(new java.awt.Font("Myanmar Text", 1, 24)); // NOI18N
        q08.setForeground(new java.awt.Color(153, 153, 153));
        q08.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        q08.setText("R168,95");
        itemsPanel.add(q08, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 290, 100, 40));

        q09.setFont(new java.awt.Font("Myanmar Text", 1, 24)); // NOI18N
        q09.setForeground(new java.awt.Color(153, 153, 153));
        q09.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        q09.setText("R329,95");
        itemsPanel.add(q09, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 290, 100, 40));

        q010.setFont(new java.awt.Font("Myanmar Text", 1, 24)); // NOI18N
        q010.setForeground(new java.awt.Color(153, 153, 153));
        q010.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        q010.setText("R164,96");
        itemsPanel.add(q010, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 290, 100, 40));

        q011.setFont(new java.awt.Font("Myanmar Text", 1, 24)); // NOI18N
        q011.setForeground(new java.awt.Color(153, 153, 153));
        q011.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        q011.setText("R107,95");
        itemsPanel.add(q011, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 450, 100, 40));

        q012.setFont(new java.awt.Font("Myanmar Text", 1, 24)); // NOI18N
        q012.setForeground(new java.awt.Color(153, 153, 153));
        q012.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        q012.setText("R64,95");
        itemsPanel.add(q012, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 450, 100, 40));

        q013.setFont(new java.awt.Font("Myanmar Text", 1, 24)); // NOI18N
        q013.setForeground(new java.awt.Color(153, 153, 153));
        q013.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        q013.setText("R64,95");
        itemsPanel.add(q013, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 450, 100, 40));

        q014.setFont(new java.awt.Font("Myanmar Text", 1, 24)); // NOI18N
        q014.setForeground(new java.awt.Color(153, 153, 153));
        q014.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        q014.setText("R137,95");
        itemsPanel.add(q014, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 450, 100, 40));

        q015.setFont(new java.awt.Font("Myanmar Text", 1, 24)); // NOI18N
        q015.setForeground(new java.awt.Color(153, 153, 153));
        q015.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        q015.setText("R164,99");
        itemsPanel.add(q015, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 450, 100, 40));

        q016.setFont(new java.awt.Font("Myanmar Text", 1, 24)); // NOI18N
        q016.setForeground(new java.awt.Color(153, 153, 153));
        q016.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        q016.setText("R49,99");
        itemsPanel.add(q016, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 600, 100, 40));

        q017.setFont(new java.awt.Font("Myanmar Text", 1, 24)); // NOI18N
        q017.setForeground(new java.awt.Color(153, 153, 153));
        q017.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        q017.setText("R224,95 ");
        itemsPanel.add(q017, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 600, 100, 40));

        q018.setFont(new java.awt.Font("Myanmar Text", 1, 24)); // NOI18N
        q018.setForeground(new java.awt.Color(153, 153, 153));
        q018.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        q018.setText("R157,95");
        itemsPanel.add(q018, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 600, 100, 40));

        q019.setFont(new java.awt.Font("Myanmar Text", 1, 24)); // NOI18N
        q019.setForeground(new java.awt.Color(153, 153, 153));
        q019.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        q019.setText("R379,95");
        itemsPanel.add(q019, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 600, 100, 40));

        q020.setFont(new java.awt.Font("Myanmar Text", 1, 24)); // NOI18N
        q020.setForeground(new java.awt.Color(153, 153, 153));
        q020.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        q020.setText("R59,95");
        itemsPanel.add(q020, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 600, 100, 40));

        jButton3.setBackground(new java.awt.Color(0, 153, 153));
        jButton3.setForeground(new java.awt.Color(255, 255, 204));
        jButton3.setText("Log Out");
        jButton3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        itemsPanel.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 100, -1));

        jButton2.setBackground(new java.awt.Color(0, 153, 153));
        jButton2.setForeground(new java.awt.Color(255, 255, 204));
        jButton2.setText("Profile");
        jButton2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        itemsPanel.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 0, 100, -1));

        jPanel.add(itemsPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 770, 670));

        delete.setBackground(new java.awt.Color(0, 153, 153));
        delete.setFont(new java.awt.Font("Myanmar Text", 3, 14)); // NOI18N
        delete.setForeground(new java.awt.Color(255, 255, 255));
        delete.setText("Delete Item");
        delete.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        delete.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteActionPerformed(evt);
            }
        });
        jPanel.add(delete, new org.netbeans.lib.awtextra.AbsoluteConstraints(1040, 450, 90, 30));

        getContentPane().add(jPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1366, 768));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Bg3.jpg"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1370, 770));

        billPanel.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        billPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        bill.setColumns(20);
        bill.setRows(5);
        jScrollPane2.setViewportView(bill);

        billPanel.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 260, 410));

        getContentPane().add(billPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(1090, 10, 260, 410));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteActionPerformed
        // Get the table model from jTable1
    DefaultTableModel dt = (DefaultTableModel) jTable1.getModel();

    // Get the index of the selected row
    int selectedRow = jTable1.getSelectedRow();

    if (selectedRow == -1) {
        // No row is selected, show error message
        JOptionPane.showMessageDialog(this, "Please select a row", "Error", JOptionPane.ERROR_MESSAGE);
    } else {
        // A row is selected, proceed with deletion
        String r = dt.getValueAt(selectedRow, 0).toString(); // Get the value of the first column (ID) of the selected row
        int productId = Integer.parseInt(r);

        // Get the quantity to add back to stock before removing the row
        int quantityToAdd = Integer.parseInt(dt.getValueAt(selectedRow, 2).toString());

        // Remove the selected row from the table
        dt.removeRow(selectedRow);

        // Remove the corresponding quantity label and reset its value to 0
        switch (productId) {
            case 1:
                q01.setVisible(true);
                q1.setVisible(false);
                q1.setText("0");
                break;
            case 2:
                q02.setVisible(true);
                q2.setVisible(false);
                q2.setText("0");
                break;
            case 3:
                q03.setVisible(true);
                q3.setVisible(false);
                q3.setText("0");
                break;
            case 4:
                q04.setVisible(true);
                q4.setVisible(false);
                q4.setText("0");
                break;
            case 5:
                q05.setVisible(true);
                q5.setVisible(false);
                q5.setText("0");
                break;
            case 6:
                q06.setVisible(true);
                q6.setVisible(false);
                q6.setText("0");
                break;
            case 7:
                q07.setVisible(true);
                q7.setVisible(false);
                q7.setText("0");
                break;
            case 8:
                q08.setVisible(true);
                q8.setVisible(false);
                q8.setText("0");
                break;
            case 9:
                q09.setVisible(true);
                q9.setVisible(false);
                q9.setText("0");
                break;
            case 10:
                q010.setVisible(true);
                q10.setVisible(false);
                q10.setText("0");
                break;
            case 11:
                q011.setVisible(true);
                q11.setVisible(false);
                q11.setText("0");
                break;
            case 12:
                q012.setVisible(true);
                q12.setVisible(false);
                q12.setText("0");
                break;
            case 13:
                q013.setVisible(true);
                q13.setVisible(false);
                q13.setText("0");
                break;
            case 14:
                q014.setVisible(true);
                q14.setVisible(false);
                q14.setText("0");
                break;
            case 15:
                q015.setVisible(true);
                q15.setVisible(false);
                q15.setText("0");
                break;
            case 16:
                q016.setVisible(true);
                q16.setVisible(false);
                q16.setText("0");
                break;
            case 17:
                q017.setVisible(true);
                q17.setVisible(false);
                q17.setText("0");
                break;
            case 18:
                q018.setVisible(true);
                q18.setVisible(false);
                q18.setText("0");
                break;
            case 19:
                q019.setVisible(true);
                q19.setVisible(false);
                q19.setText("0");
                break;
            case 20:
                q020.setVisible(true);
                q20.setVisible(false);
                q20.setText("0");
                break;
            default:
                System.out.println("Invalid product ID");
        }

        // Update the stock level in the database
        try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish connection to the database
            con = DriverManager.getConnection(url, "root", "Admin#01");

            // Prepare SQL query to update the stock
            String query = "UPDATE Products SET stock = stock + ? WHERE Id = ?";
            pst = con.prepareStatement(query);

            // Set the parameters for the query
            pst.setInt(1, quantityToAdd);
            pst.setInt(2, productId);

            // Execute the update query
            int result = pst.executeUpdate();
            if (result > 0) {
                System.out.println("Stock updated successfully.");
            } else {
                System.out.println("Failed to update stock.");
            }

        } catch (Exception e) {
            // Display any exceptions that occur
            JOptionPane.showMessageDialog(null, e);
        } finally {
            // Close resources
            try {
                if (pst != null) pst.close();
                if (con != null) con.close();
            } catch (Exception e) {
                // Display any exceptions that occur
                JOptionPane.showMessageDialog(null, e);
            }
        }

        // Recalculate the total after deleting the item
        cal();
    }
    }//GEN-LAST:event_deleteActionPerformed

    private void jButton21ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton21ActionPerformed
        try {
            // Call the pay method to process the payment
            pay();

            // Print the bill
            bill.print();

        } catch (PrinterException e) {
            // Print the exception to the console if printing fails
            System.out.println(e);
        }
        
        // Send bill to user's email address
        String subject = "Your PharmaBright Pharmacy Bill";
        String messageContent = "<html>" + generateBill() + "</html>"; // Use HTML format for the email

        sendEmail(Login.emailAddress, subject, messageContent);
    }//GEN-LAST:event_jButton21ActionPerformed

    private void p1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p1ActionPerformed
        try {
        // Load MySQL JDBC Driver
        Class.forName("com.mysql.cj.jdbc.Driver");

        // Establish connection to the database
        con = DriverManager.getConnection(url, "root", "Admin#01");

        // Prepare SQL query to retrieve product data
        String query = "SELECT Id, Name, price, stock FROM Products WHERE Id = ?";
        pst = con.prepareStatement(query);
        pst.setInt(1, 1);

        // Execute the query and get the result
        rs = pst.executeQuery();

        if (rs.next()) {
            int id = rs.getInt("Id");
            String name = rs.getString("Name");
            double price = rs.getDouble("price");
            int stock = rs.getInt("stock");

            if (stock > 0) {
                // Hide the 'q01' component and show the 'q1' component
                q01.setVisible(false);
                q1.setVisible(true);

                // Get the current value from 'q1', increment it, and update 'q1' with the new value
                int quantity = Integer.valueOf(q1.getText());
                ++quantity;
                q1.setText(String.valueOf(quantity));

                // Add the item to the table with updated quantity
                addtables(id, name, quantity, price);

                // Update the stock level in the database
                String updateQuery = "UPDATE Products SET stock = ? WHERE Id = ?";
                PreparedStatement updatePst = con.prepareStatement(updateQuery);
                updatePst.setInt(1, stock - 1);
                updatePst.setInt(2, id);

                // Execute the update query
                int result = updatePst.executeUpdate();
                if (result > 0) {
                    System.out.println("Stock updated successfully.");
                } else {
                    System.out.println("Failed to update stock.");
                }

                // Close the update PreparedStatement
                updatePst.close();
            } else {
                JOptionPane.showMessageDialog(null, "Out of stock.");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Product not found.");
        }
    } catch (Exception e) {
        // Display any exceptions that occur
        JOptionPane.showMessageDialog(null, e);
    } finally {
        // Close resources
        try {
            if (rs != null) rs.close();
            if (pst != null) pst.close();
            if (con != null) con.close();
        } catch (Exception e) {
            // Display any exceptions that occur
            JOptionPane.showMessageDialog(null, e);
        }
    }

    // Recalculate the total after adding the item
    cal();
    }//GEN-LAST:event_p1ActionPerformed

    private void p3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p3ActionPerformed
        try {
        // Load MySQL JDBC Driver
        Class.forName("com.mysql.cj.jdbc.Driver");

        // Establish connection to the database
        con = DriverManager.getConnection(url, "root", "Admin#01");

        // Prepare SQL query to retrieve product data
        String query = "SELECT Id, Name, price, stock FROM Products WHERE Id = ?";
        pst = con.prepareStatement(query);
        pst.setInt(1, 3);

        // Execute the query and get the result
        rs = pst.executeQuery();

        if (rs.next()) {
            int id = rs.getInt("Id");
            String name = rs.getString("Name");
            double price = rs.getDouble("price");
            int stock = rs.getInt("stock");

            if (stock > 0) {
                // Hide the 'q01' component and show the 'q1' component
                q03.setVisible(false);
                q3.setVisible(true);

                // Get the current value from 'q1', increment it, and update 'q1' with the new value
                int quantity = Integer.valueOf(q3.getText());
                ++quantity;
                q3.setText(String.valueOf(quantity));

                // Add the item to the table with updated quantity
                addtables(id, name, quantity, price);

                // Update the stock level in the database
                String updateQuery = "UPDATE Products SET stock = ? WHERE Id = ?";
                PreparedStatement updatePst = con.prepareStatement(updateQuery);
                updatePst.setInt(1, stock - 1);
                updatePst.setInt(2, id);

                // Execute the update query
                int result = updatePst.executeUpdate();
                if (result > 0) {
                    System.out.println("Stock updated successfully.");
                } else {
                    System.out.println("Failed to update stock.");
                }

                // Close the update PreparedStatement
                updatePst.close();
            } else {
                JOptionPane.showMessageDialog(null, "Out of stock.");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Product not found.");
        }
    } catch (Exception e) {
        // Display any exceptions that occur
        JOptionPane.showMessageDialog(null, e);
    } finally {
        // Close resources
        try {
            if (rs != null) rs.close();
            if (pst != null) pst.close();
            if (con != null) con.close();
        } catch (Exception e) {
            // Display any exceptions that occur
            JOptionPane.showMessageDialog(null, e);
        }
    }

    // Recalculate the total after adding the item
    cal();
    }//GEN-LAST:event_p3ActionPerformed

    private void p2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p2ActionPerformed
        try {
        // Load MySQL JDBC Driver
        Class.forName("com.mysql.cj.jdbc.Driver");

        // Establish connection to the database
        con = DriverManager.getConnection(url, "root", "Admin#01");

        // Prepare SQL query to retrieve product data
        String query = "SELECT Id, Name, price, stock FROM Products WHERE Id = ?";
        pst = con.prepareStatement(query);
        pst.setInt(1, 2);

        // Execute the query and get the result
        rs = pst.executeQuery();

        if (rs.next()) {
            int id = rs.getInt("Id");
            String name = rs.getString("Name");
            double price = rs.getDouble("price");
            int stock = rs.getInt("stock");

            if (stock > 0) {
                // Hide the 'q01' component and show the 'q1' component
                q02.setVisible(false);
                q2.setVisible(true);

                // Get the current value from 'q1', increment it, and update 'q1' with the new value
                int quantity = Integer.valueOf(q2.getText());
                ++quantity;
                q2.setText(String.valueOf(quantity));

                // Add the item to the table with updated quantity
                addtables(id, name, quantity, price);

                // Update the stock level in the database
                String updateQuery = "UPDATE Products SET stock = ? WHERE Id = ?";
                PreparedStatement updatePst = con.prepareStatement(updateQuery);
                updatePst.setInt(1, stock - 1);
                updatePst.setInt(2, id);

                // Execute the update query
                int result = updatePst.executeUpdate();
                if (result > 0) {
                    System.out.println("Stock updated successfully.");
                } else {
                    System.out.println("Failed to update stock.");
                }

                // Close the update PreparedStatement
                updatePst.close();
            } else {
                JOptionPane.showMessageDialog(null, "Out of stock.");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Product not found.");
        }
    } catch (Exception e) {
        // Display any exceptions that occur
        JOptionPane.showMessageDialog(null, e);
    } finally {
        // Close resources
        try {
            if (rs != null) rs.close();
            if (pst != null) pst.close();
            if (con != null) con.close();
        } catch (Exception e) {
            // Display any exceptions that occur
            JOptionPane.showMessageDialog(null, e);
        }
    }

    // Recalculate the total after adding the item
    cal();
    }//GEN-LAST:event_p2ActionPerformed

    private void payAmtKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_payAmtKeyTyped
        // Get the typed character
        char c = evt.getKeyChar();

        // Allow only digits and one dot
        if (!Character.isDigit(c) && c != '.') {
            // Consume the event to prevent non-digit and non-dot characters from being entered
            evt.consume();
        } else if (c == '.' && payAmt.getText().contains(".")) {
            // If a dot is already present, consume the event to prevent multiple dots
            evt.consume();
        }
    }//GEN-LAST:event_payAmtKeyTyped

    private void payAmtKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_payAmtKeyReleased
        // Call the pay method to update payment-related calculations
        pay();
    }//GEN-LAST:event_payAmtKeyReleased

    private void p4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p4ActionPerformed
        try {
        // Load MySQL JDBC Driver
        Class.forName("com.mysql.cj.jdbc.Driver");

        // Establish connection to the database
        con = DriverManager.getConnection(url, "root", "Admin#01");

        // Prepare SQL query to retrieve product data
        String query = "SELECT Id, Name, price, stock FROM Products WHERE Id = ?";
        pst = con.prepareStatement(query);
        pst.setInt(1, 4);

        // Execute the query and get the result
        rs = pst.executeQuery();

        if (rs.next()) {
            int id = rs.getInt("Id");
            String name = rs.getString("Name");
            double price = rs.getDouble("price");
            int stock = rs.getInt("stock");

            if (stock > 0) {
                // Hide the 'q01' component and show the 'q1' component
                q04.setVisible(false);
                q4.setVisible(true);

                // Get the current value from 'q1', increment it, and update 'q1' with the new value
                int quantity = Integer.valueOf(q4.getText());
                ++quantity;
                q4.setText(String.valueOf(quantity));

                // Add the item to the table with updated quantity
                addtables(id, name, quantity, price);

                // Update the stock level in the database
                String updateQuery = "UPDATE Products SET stock = ? WHERE Id = ?";
                PreparedStatement updatePst = con.prepareStatement(updateQuery);
                updatePst.setInt(1, stock - 1);
                updatePst.setInt(2, id);

                // Execute the update query
                int result = updatePst.executeUpdate();
                if (result > 0) {
                    System.out.println("Stock updated successfully.");
                } else {
                    System.out.println("Failed to update stock.");
                }

                // Close the update PreparedStatement
                updatePst.close();
            } else {
                JOptionPane.showMessageDialog(null, "Out of stock.");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Product not found.");
        }
    } catch (Exception e) {
        // Display any exceptions that occur
        JOptionPane.showMessageDialog(null, e);
    } finally {
        // Close resources
        try {
            if (rs != null) rs.close();
            if (pst != null) pst.close();
            if (con != null) con.close();
        } catch (Exception e) {
            // Display any exceptions that occur
            JOptionPane.showMessageDialog(null, e);
        }
    }

    // Recalculate the total after adding the item
    cal();
    }//GEN-LAST:event_p4ActionPerformed

    private void p5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p5ActionPerformed
        try {
        // Load MySQL JDBC Driver
        Class.forName("com.mysql.cj.jdbc.Driver");

        // Establish connection to the database
        con = DriverManager.getConnection(url, "root", "Admin#01");

        // Prepare SQL query to retrieve product data
        String query = "SELECT Id, Name, price, stock FROM Products WHERE Id = ?";
        pst = con.prepareStatement(query);
        pst.setInt(1, 5);

        // Execute the query and get the result
        rs = pst.executeQuery();

        if (rs.next()) {
            int id = rs.getInt("Id");
            String name = rs.getString("Name");
            double price = rs.getDouble("price");
            int stock = rs.getInt("stock");

            if (stock > 0) {
                // Hide the 'q01' component and show the 'q1' component
                q05.setVisible(false);
                q5.setVisible(true);

                // Get the current value from 'q1', increment it, and update 'q1' with the new value
                int quantity = Integer.valueOf(q5.getText());
                ++quantity;
                q5.setText(String.valueOf(quantity));

                // Add the item to the table with updated quantity
                addtables(id, name, quantity, price);

                // Update the stock level in the database
                String updateQuery = "UPDATE Products SET stock = ? WHERE Id = ?";
                PreparedStatement updatePst = con.prepareStatement(updateQuery);
                updatePst.setInt(1, stock - 1);
                updatePst.setInt(2, id);

                // Execute the update query
                int result = updatePst.executeUpdate();
                if (result > 0) {
                    System.out.println("Stock updated successfully.");
                } else {
                    System.out.println("Failed to update stock.");
                }

                // Close the update PreparedStatement
                updatePst.close();
            } else {
                JOptionPane.showMessageDialog(null, "Out of stock.");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Product not found.");
        }
    } catch (Exception e) {
        // Display any exceptions that occur
        JOptionPane.showMessageDialog(null, e);
    } finally {
        // Close resources
        try {
            if (rs != null) rs.close();
            if (pst != null) pst.close();
            if (con != null) con.close();
        } catch (Exception e) {
            // Display any exceptions that occur
            JOptionPane.showMessageDialog(null, e);
        }
    }

    // Recalculate the total after adding the item
    cal();
    }//GEN-LAST:event_p5ActionPerformed

    private void p6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p6ActionPerformed
        try {
        // Load MySQL JDBC Driver
        Class.forName("com.mysql.cj.jdbc.Driver");

        // Establish connection to the database
        con = DriverManager.getConnection(url, "root", "Admin#01");

        // Prepare SQL query to retrieve product data
        String query = "SELECT Id, Name, price, stock FROM Products WHERE Id = ?";
        pst = con.prepareStatement(query);
        pst.setInt(1, 6);

        // Execute the query and get the result
        rs = pst.executeQuery();

        if (rs.next()) {
            int id = rs.getInt("Id");
            String name = rs.getString("Name");
            double price = rs.getDouble("price");
            int stock = rs.getInt("stock");

            if (stock > 0) {
                // Hide the 'q01' component and show the 'q1' component
                q06.setVisible(false);
                q6.setVisible(true);

                // Get the current value from 'q1', increment it, and update 'q1' with the new value
                int quantity = Integer.valueOf(q6.getText());
                ++quantity;
                q6.setText(String.valueOf(quantity));

                // Add the item to the table with updated quantity
                addtables(id, name, quantity, price);

                // Update the stock level in the database
                String updateQuery = "UPDATE Products SET stock = ? WHERE Id = ?";
                PreparedStatement updatePst = con.prepareStatement(updateQuery);
                updatePst.setInt(1, stock - 1);
                updatePst.setInt(2, id);

                // Execute the update query
                int result = updatePst.executeUpdate();
                if (result > 0) {
                    System.out.println("Stock updated successfully.");
                } else {
                    System.out.println("Failed to update stock.");
                }

                // Close the update PreparedStatement
                updatePst.close();
            } else {
                JOptionPane.showMessageDialog(null, "Out of stock.");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Product not found.");
        }
    } catch (Exception e) {
        // Display any exceptions that occur
        JOptionPane.showMessageDialog(null, e);
    } finally {
        // Close resources
        try {
            if (rs != null) rs.close();
            if (pst != null) pst.close();
            if (con != null) con.close();
        } catch (Exception e) {
            // Display any exceptions that occur
            JOptionPane.showMessageDialog(null, e);
        }
    }

    // Recalculate the total after adding the item
    cal();
    }//GEN-LAST:event_p6ActionPerformed

    private void p7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p7ActionPerformed
       try {
        // Load MySQL JDBC Driver
        Class.forName("com.mysql.cj.jdbc.Driver");

        // Establish connection to the database
        con = DriverManager.getConnection(url, "root", "Admin#01");

        // Prepare SQL query to retrieve product data
        String query = "SELECT Id, Name, price, stock FROM Products WHERE Id = ?";
        pst = con.prepareStatement(query);
        pst.setInt(1, 7);

        // Execute the query and get the result
        rs = pst.executeQuery();

        if (rs.next()) {
            int id = rs.getInt("Id");
            String name = rs.getString("Name");
            double price = rs.getDouble("price");
            int stock = rs.getInt("stock");

            if (stock > 0) {
                // Hide the 'q01' component and show the 'q1' component
                q07.setVisible(false);
                q7.setVisible(true);

                // Get the current value from 'q1', increment it, and update 'q1' with the new value
                int quantity = Integer.valueOf(q7.getText());
                ++quantity;
                q7.setText(String.valueOf(quantity));

                // Add the item to the table with updated quantity
                addtables(id, name, quantity, price);

                // Update the stock level in the database
                String updateQuery = "UPDATE Products SET stock = ? WHERE Id = ?";
                PreparedStatement updatePst = con.prepareStatement(updateQuery);
                updatePst.setInt(1, stock - 1);
                updatePst.setInt(2, id);

                // Execute the update query
                int result = updatePst.executeUpdate();
                if (result > 0) {
                    System.out.println("Stock updated successfully.");
                } else {
                    System.out.println("Failed to update stock.");
                }

                // Close the update PreparedStatement
                updatePst.close();
            } else {
                JOptionPane.showMessageDialog(null, "Out of stock.");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Product not found.");
        }
    } catch (Exception e) {
        // Display any exceptions that occur
        JOptionPane.showMessageDialog(null, e);
    } finally {
        // Close resources
        try {
            if (rs != null) rs.close();
            if (pst != null) pst.close();
            if (con != null) con.close();
        } catch (Exception e) {
            // Display any exceptions that occur
            JOptionPane.showMessageDialog(null, e);
        }
    }

    // Recalculate the total after adding the item
    cal(); 
    }//GEN-LAST:event_p7ActionPerformed

    private void p8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p8ActionPerformed
        try {
        // Load MySQL JDBC Driver
        Class.forName("com.mysql.cj.jdbc.Driver");

        // Establish connection to the database
        con = DriverManager.getConnection(url, "root", "Admin#01");

        // Prepare SQL query to retrieve product data
        String query = "SELECT Id, Name, price, stock FROM Products WHERE Id = ?";
        pst = con.prepareStatement(query);
        pst.setInt(1, 8);

        // Execute the query and get the result
        rs = pst.executeQuery();

        if (rs.next()) {
            int id = rs.getInt("Id");
            String name = rs.getString("Name");
            double price = rs.getDouble("price");
            int stock = rs.getInt("stock");

            if (stock > 0) {
                // Hide the 'q01' component and show the 'q1' component
                q08.setVisible(false);
                q8.setVisible(true);

                // Get the current value from 'q1', increment it, and update 'q1' with the new value
                int quantity = Integer.valueOf(q8.getText());
                ++quantity;
                q8.setText(String.valueOf(quantity));

                // Add the item to the table with updated quantity
                addtables(id, name, quantity, price);

                // Update the stock level in the database
                String updateQuery = "UPDATE Products SET stock = ? WHERE Id = ?";
                PreparedStatement updatePst = con.prepareStatement(updateQuery);
                updatePst.setInt(1, stock - 1);
                updatePst.setInt(2, id);

                // Execute the update query
                int result = updatePst.executeUpdate();
                if (result > 0) {
                    System.out.println("Stock updated successfully.");
                } else {
                    System.out.println("Failed to update stock.");
                }

                // Close the update PreparedStatement
                updatePst.close();
            } else {
                JOptionPane.showMessageDialog(null, "Out of stock.");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Product not found.");
        }
    } catch (Exception e) {
        // Display any exceptions that occur
        JOptionPane.showMessageDialog(null, e);
    } finally {
        // Close resources
        try {
            if (rs != null) rs.close();
            if (pst != null) pst.close();
            if (con != null) con.close();
        } catch (Exception e) {
            // Display any exceptions that occur
            JOptionPane.showMessageDialog(null, e);
        }
    }

    // Recalculate the total after adding the item
    cal();
    }//GEN-LAST:event_p8ActionPerformed

    private void p9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p9ActionPerformed
        try {
        // Load MySQL JDBC Driver
        Class.forName("com.mysql.cj.jdbc.Driver");

        // Establish connection to the database
        con = DriverManager.getConnection(url, "root", "Admin#01");

        // Prepare SQL query to retrieve product data
        String query = "SELECT Id, Name, price, stock FROM Products WHERE Id = ?";
        pst = con.prepareStatement(query);
        pst.setInt(1, 9);

        // Execute the query and get the result
        rs = pst.executeQuery();

        if (rs.next()) {
            int id = rs.getInt("Id");
            String name = rs.getString("Name");
            double price = rs.getDouble("price");
            int stock = rs.getInt("stock");

            if (stock > 0) {
                // Hide the 'q01' component and show the 'q1' component
                q09.setVisible(false);
                q9.setVisible(true);

                // Get the current value from 'q1', increment it, and update 'q1' with the new value
                int quantity = Integer.valueOf(q9.getText());
                ++quantity;
                q9.setText(String.valueOf(quantity));

                // Add the item to the table with updated quantity
                addtables(id, name, quantity, price);

                // Update the stock level in the database
                String updateQuery = "UPDATE Products SET stock = ? WHERE Id = ?";
                PreparedStatement updatePst = con.prepareStatement(updateQuery);
                updatePst.setInt(1, stock - 1);
                updatePst.setInt(2, id);

                // Execute the update query
                int result = updatePst.executeUpdate();
                if (result > 0) {
                    System.out.println("Stock updated successfully.");
                } else {
                    System.out.println("Failed to update stock.");
                }

                // Close the update PreparedStatement
                updatePst.close();
            } else {
                JOptionPane.showMessageDialog(null, "Out of stock.");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Product not found.");
        }
    } catch (Exception e) {
        // Display any exceptions that occur
        JOptionPane.showMessageDialog(null, e);
    } finally {
        // Close resources
        try {
            if (rs != null) rs.close();
            if (pst != null) pst.close();
            if (con != null) con.close();
        } catch (Exception e) {
            // Display any exceptions that occur
            JOptionPane.showMessageDialog(null, e);
        }
    }

    // Recalculate the total after adding the item
    cal();
    }//GEN-LAST:event_p9ActionPerformed

    private void p10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p10ActionPerformed
        try {
        // Load MySQL JDBC Driver
        Class.forName("com.mysql.cj.jdbc.Driver");

        // Establish connection to the database
        con = DriverManager.getConnection(url, "root", "Admin#01");

        // Prepare SQL query to retrieve product data
        String query = "SELECT Id, Name, price, stock FROM Products WHERE Id = ?";
        pst = con.prepareStatement(query);
        pst.setInt(1, 10);

        // Execute the query and get the result
        rs = pst.executeQuery();

        if (rs.next()) {
            int id = rs.getInt("Id");
            String name = rs.getString("Name");
            double price = rs.getDouble("price");
            int stock = rs.getInt("stock");

            if (stock > 0) {
                // Hide the 'q01' component and show the 'q1' component
                q010.setVisible(false);
                q10.setVisible(true);

                // Get the current value from 'q1', increment it, and update 'q1' with the new value
                int quantity = Integer.valueOf(q10.getText());
                ++quantity;
                q10.setText(String.valueOf(quantity));

                // Add the item to the table with updated quantity
                addtables(id, name, quantity, price);

                // Update the stock level in the database
                String updateQuery = "UPDATE Products SET stock = ? WHERE Id = ?";
                PreparedStatement updatePst = con.prepareStatement(updateQuery);
                updatePst.setInt(1, stock - 1);
                updatePst.setInt(2, id);

                // Execute the update query
                int result = updatePst.executeUpdate();
                if (result > 0) {
                    System.out.println("Stock updated successfully.");
                } else {
                    System.out.println("Failed to update stock.");
                }

                // Close the update PreparedStatement
                updatePst.close();
            } else {
                JOptionPane.showMessageDialog(null, "Out of stock.");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Product not found.");
        }
    } catch (Exception e) {
        // Display any exceptions that occur
        JOptionPane.showMessageDialog(null, e);
    } finally {
        // Close resources
        try {
            if (rs != null) rs.close();
            if (pst != null) pst.close();
            if (con != null) con.close();
        } catch (Exception e) {
            // Display any exceptions that occur
            JOptionPane.showMessageDialog(null, e);
        }
    }

    // Recalculate the total after adding the item
    cal();
    }//GEN-LAST:event_p10ActionPerformed

    private void p11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p11ActionPerformed
        try {
        // Load MySQL JDBC Driver
        Class.forName("com.mysql.cj.jdbc.Driver");

        // Establish connection to the database
        con = DriverManager.getConnection(url, "root", "Admin#01");

        // Prepare SQL query to retrieve product data
        String query = "SELECT Id, Name, price, stock FROM Products WHERE Id = ?";
        pst = con.prepareStatement(query);
        pst.setInt(1, 11);

        // Execute the query and get the result
        rs = pst.executeQuery();

        if (rs.next()) {
            int id = rs.getInt("Id");
            String name = rs.getString("Name");
            double price = rs.getDouble("price");
            int stock = rs.getInt("stock");

            if (stock > 0) {
                // Hide the 'q01' component and show the 'q1' component
                q011.setVisible(false);
                q11.setVisible(true);

                // Get the current value from 'q1', increment it, and update 'q1' with the new value
                int quantity = Integer.valueOf(q11.getText());
                ++quantity;
                q11.setText(String.valueOf(quantity));

                // Add the item to the table with updated quantity
                addtables(id, name, quantity, price);

                // Update the stock level in the database
                String updateQuery = "UPDATE Products SET stock = ? WHERE Id = ?";
                PreparedStatement updatePst = con.prepareStatement(updateQuery);
                updatePst.setInt(1, stock - 1);
                updatePst.setInt(2, id);

                // Execute the update query
                int result = updatePst.executeUpdate();
                if (result > 0) {
                    System.out.println("Stock updated successfully.");
                } else {
                    System.out.println("Failed to update stock.");
                }

                // Close the update PreparedStatement
                updatePst.close();
            } else {
                JOptionPane.showMessageDialog(null, "Out of stock.");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Product not found.");
        }
    } catch (Exception e) {
        // Display any exceptions that occur
        JOptionPane.showMessageDialog(null, e);
    } finally {
        // Close resources
        try {
            if (rs != null) rs.close();
            if (pst != null) pst.close();
            if (con != null) con.close();
        } catch (Exception e) {
            // Display any exceptions that occur
            JOptionPane.showMessageDialog(null, e);
        }
    }

    // Recalculate the total after adding the item
    cal();
    }//GEN-LAST:event_p11ActionPerformed

    private void p12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p12ActionPerformed
        try {
        // Load MySQL JDBC Driver
        Class.forName("com.mysql.cj.jdbc.Driver");

        // Establish connection to the database
        con = DriverManager.getConnection(url, "root", "Admin#01");

        // Prepare SQL query to retrieve product data
        String query = "SELECT Id, Name, price, stock FROM Products WHERE Id = ?";
        pst = con.prepareStatement(query);
        pst.setInt(1, 12);

        // Execute the query and get the result
        rs = pst.executeQuery();

        if (rs.next()) {
            int id = rs.getInt("Id");
            String name = rs.getString("Name");
            double price = rs.getDouble("price");
            int stock = rs.getInt("stock");

            if (stock > 0) {
                // Hide the 'q01' component and show the 'q1' component
                q012.setVisible(false);
                q12.setVisible(true);

                // Get the current value from 'q1', increment it, and update 'q1' with the new value
                int quantity = Integer.valueOf(q12.getText());
                ++quantity;
                q12.setText(String.valueOf(quantity));

                // Add the item to the table with updated quantity
                addtables(id, name, quantity, price);

                // Update the stock level in the database
                String updateQuery = "UPDATE Products SET stock = ? WHERE Id = ?";
                PreparedStatement updatePst = con.prepareStatement(updateQuery);
                updatePst.setInt(1, stock - 1);
                updatePst.setInt(2, id);

                // Execute the update query
                int result = updatePst.executeUpdate();
                if (result > 0) {
                    System.out.println("Stock updated successfully.");
                } else {
                    System.out.println("Failed to update stock.");
                }

                // Close the update PreparedStatement
                updatePst.close();
            } else {
                JOptionPane.showMessageDialog(null, "Out of stock.");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Product not found.");
        }
    } catch (Exception e) {
        // Display any exceptions that occur
        JOptionPane.showMessageDialog(null, e);
    } finally {
        // Close resources
        try {
            if (rs != null) rs.close();
            if (pst != null) pst.close();
            if (con != null) con.close();
        } catch (Exception e) {
            // Display any exceptions that occur
            JOptionPane.showMessageDialog(null, e);
        }
    }

    // Recalculate the total after adding the item
    cal();
    }//GEN-LAST:event_p12ActionPerformed

    private void p13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p13ActionPerformed
        try {
        // Load MySQL JDBC Driver
        Class.forName("com.mysql.cj.jdbc.Driver");

        // Establish connection to the database
        con = DriverManager.getConnection(url, "root", "Admin#01");

        // Prepare SQL query to retrieve product data
        String query = "SELECT Id, Name, price, stock FROM Products WHERE Id = ?";
        pst = con.prepareStatement(query);
        pst.setInt(1, 13);

        // Execute the query and get the result
        rs = pst.executeQuery();

        if (rs.next()) {
            int id = rs.getInt("Id");
            String name = rs.getString("Name");
            double price = rs.getDouble("price");
            int stock = rs.getInt("stock");

            if (stock > 0) {
                // Hide the 'q01' component and show the 'q1' component
                q013.setVisible(false);
                q13.setVisible(true);

                // Get the current value from 'q1', increment it, and update 'q1' with the new value
                int quantity = Integer.valueOf(q13.getText());
                ++quantity;
                q13.setText(String.valueOf(quantity));

                // Add the item to the table with updated quantity
                addtables(id, name, quantity, price);

                // Update the stock level in the database
                String updateQuery = "UPDATE Products SET stock = ? WHERE Id = ?";
                PreparedStatement updatePst = con.prepareStatement(updateQuery);
                updatePst.setInt(1, stock - 1);
                updatePst.setInt(2, id);

                // Execute the update query
                int result = updatePst.executeUpdate();
                if (result > 0) {
                    System.out.println("Stock updated successfully.");
                } else {
                    System.out.println("Failed to update stock.");
                }

                // Close the update PreparedStatement
                updatePst.close();
            } else {
                JOptionPane.showMessageDialog(null, "Out of stock.");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Product not found.");
        }
    } catch (Exception e) {
        // Display any exceptions that occur
        JOptionPane.showMessageDialog(null, e);
    } finally {
        // Close resources
        try {
            if (rs != null) rs.close();
            if (pst != null) pst.close();
            if (con != null) con.close();
        } catch (Exception e) {
            // Display any exceptions that occur
            JOptionPane.showMessageDialog(null, e);
        }
    }

    // Recalculate the total after adding the item
    cal();
    }//GEN-LAST:event_p13ActionPerformed

    private void p14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p14ActionPerformed
        try {
        // Load MySQL JDBC Driver
        Class.forName("com.mysql.cj.jdbc.Driver");

        // Establish connection to the database
        con = DriverManager.getConnection(url, "root", "Admin#01");

        // Prepare SQL query to retrieve product data
        String query = "SELECT Id, Name, price, stock FROM Products WHERE Id = ?";
        pst = con.prepareStatement(query);
        pst.setInt(1, 14);

        // Execute the query and get the result
        rs = pst.executeQuery();

        if (rs.next()) {
            int id = rs.getInt("Id");
            String name = rs.getString("Name");
            double price = rs.getDouble("price");
            int stock = rs.getInt("stock");

            if (stock > 0) {
                // Hide the 'q01' component and show the 'q1' component
                q014.setVisible(false);
                q14.setVisible(true);

                // Get the current value from 'q1', increment it, and update 'q1' with the new value
                int quantity = Integer.valueOf(q14.getText());
                ++quantity;
                q14.setText(String.valueOf(quantity));

                // Add the item to the table with updated quantity
                addtables(id, name, quantity, price);

                // Update the stock level in the database
                String updateQuery = "UPDATE Products SET stock = ? WHERE Id = ?";
                PreparedStatement updatePst = con.prepareStatement(updateQuery);
                updatePst.setInt(1, stock - 1);
                updatePst.setInt(2, id);

                // Execute the update query
                int result = updatePst.executeUpdate();
                if (result > 0) {
                    System.out.println("Stock updated successfully.");
                } else {
                    System.out.println("Failed to update stock.");
                }

                // Close the update PreparedStatement
                updatePst.close();
            } else {
                JOptionPane.showMessageDialog(null, "Out of stock.");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Product not found.");
        }
    } catch (Exception e) {
        // Display any exceptions that occur
        JOptionPane.showMessageDialog(null, e);
    } finally {
        // Close resources
        try {
            if (rs != null) rs.close();
            if (pst != null) pst.close();
            if (con != null) con.close();
        } catch (Exception e) {
            // Display any exceptions that occur
            JOptionPane.showMessageDialog(null, e);
        }
    }

    // Recalculate the total after adding the item
    cal();
    }//GEN-LAST:event_p14ActionPerformed

    private void p15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p15ActionPerformed
        try {
        // Load MySQL JDBC Driver
        Class.forName("com.mysql.cj.jdbc.Driver");

        // Establish connection to the database
        con = DriverManager.getConnection(url, "root", "Admin#01");

        // Prepare SQL query to retrieve product data
        String query = "SELECT Id, Name, price, stock FROM Products WHERE Id = ?";
        pst = con.prepareStatement(query);
        pst.setInt(1, 15);

        // Execute the query and get the result
        rs = pst.executeQuery();

        if (rs.next()) {
            int id = rs.getInt("Id");
            String name = rs.getString("Name");
            double price = rs.getDouble("price");
            int stock = rs.getInt("stock");

            if (stock > 0) {
                // Hide the 'q01' component and show the 'q1' component
                q015.setVisible(false);
                q15.setVisible(true);

                // Get the current value from 'q1', increment it, and update 'q1' with the new value
                int quantity = Integer.valueOf(q15.getText());
                ++quantity;
                q15.setText(String.valueOf(quantity));

                // Add the item to the table with updated quantity
                addtables(id, name, quantity, price);

                // Update the stock level in the database
                String updateQuery = "UPDATE Products SET stock = ? WHERE Id = ?";
                PreparedStatement updatePst = con.prepareStatement(updateQuery);
                updatePst.setInt(1, stock - 1);
                updatePst.setInt(2, id);

                // Execute the update query
                int result = updatePst.executeUpdate();
                if (result > 0) {
                    System.out.println("Stock updated successfully.");
                } else {
                    System.out.println("Failed to update stock.");
                }

                // Close the update PreparedStatement
                updatePst.close();
            } else {
                JOptionPane.showMessageDialog(null, "Out of stock.");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Product not found.");
        }
    } catch (Exception e) {
        // Display any exceptions that occur
        JOptionPane.showMessageDialog(null, e);
    } finally {
        // Close resources
        try {
            if (rs != null) rs.close();
            if (pst != null) pst.close();
            if (con != null) con.close();
        } catch (Exception e) {
            // Display any exceptions that occur
            JOptionPane.showMessageDialog(null, e);
        }
    }

    // Recalculate the total after adding the item
    cal();
    }//GEN-LAST:event_p15ActionPerformed

    private void p16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p16ActionPerformed
        try {
        // Load MySQL JDBC Driver
        Class.forName("com.mysql.cj.jdbc.Driver");

        // Establish connection to the database
        con = DriverManager.getConnection(url, "root", "Admin#01");

        // Prepare SQL query to retrieve product data
        String query = "SELECT Id, Name, price, stock FROM Products WHERE Id = ?";
        pst = con.prepareStatement(query);
        pst.setInt(1, 16);

        // Execute the query and get the result
        rs = pst.executeQuery();

        if (rs.next()) {
            int id = rs.getInt("Id");
            String name = rs.getString("Name");
            double price = rs.getDouble("price");
            int stock = rs.getInt("stock");

            if (stock > 0) {
                // Hide the 'q01' component and show the 'q1' component
                q016.setVisible(false);
                q16.setVisible(true);

                // Get the current value from 'q1', increment it, and update 'q1' with the new value
                int quantity = Integer.valueOf(q16.getText());
                ++quantity;
                q16.setText(String.valueOf(quantity));

                // Add the item to the table with updated quantity
                addtables(id, name, quantity, price);

                // Update the stock level in the database
                String updateQuery = "UPDATE Products SET stock = ? WHERE Id = ?";
                PreparedStatement updatePst = con.prepareStatement(updateQuery);
                updatePst.setInt(1, stock - 1);
                updatePst.setInt(2, id);

                // Execute the update query
                int result = updatePst.executeUpdate();
                if (result > 0) {
                    System.out.println("Stock updated successfully.");
                } else {
                    System.out.println("Failed to update stock.");
                }

                // Close the update PreparedStatement
                updatePst.close();
            } else {
                JOptionPane.showMessageDialog(null, "Out of stock.");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Product not found.");
        }
    } catch (Exception e) {
        // Display any exceptions that occur
        JOptionPane.showMessageDialog(null, e);
    } finally {
        // Close resources
        try {
            if (rs != null) rs.close();
            if (pst != null) pst.close();
            if (con != null) con.close();
        } catch (Exception e) {
            // Display any exceptions that occur
            JOptionPane.showMessageDialog(null, e);
        }
    }

    // Recalculate the total after adding the item
    cal();
    }//GEN-LAST:event_p16ActionPerformed

    private void p17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p17ActionPerformed
        try {
        // Load MySQL JDBC Driver
        Class.forName("com.mysql.cj.jdbc.Driver");

        // Establish connection to the database
        con = DriverManager.getConnection(url, "root", "Admin#01");

        // Prepare SQL query to retrieve product data
        String query = "SELECT Id, Name, price, stock FROM Products WHERE Id = ?";
        pst = con.prepareStatement(query);
        pst.setInt(1, 17);

        // Execute the query and get the result
        rs = pst.executeQuery();

        if (rs.next()) {
            int id = rs.getInt("Id");
            String name = rs.getString("Name");
            double price = rs.getDouble("price");
            int stock = rs.getInt("stock");

            if (stock > 0) {
                // Hide the 'q01' component and show the 'q1' component
                q017.setVisible(false);
                q17.setVisible(true);

                // Get the current value from 'q1', increment it, and update 'q1' with the new value
                int quantity = Integer.valueOf(q17.getText());
                ++quantity;
                q17.setText(String.valueOf(quantity));

                // Add the item to the table with updated quantity
                addtables(id, name, quantity, price);

                // Update the stock level in the database
                String updateQuery = "UPDATE Products SET stock = ? WHERE Id = ?";
                PreparedStatement updatePst = con.prepareStatement(updateQuery);
                updatePst.setInt(1, stock - 1);
                updatePst.setInt(2, id);

                // Execute the update query
                int result = updatePst.executeUpdate();
                if (result > 0) {
                    System.out.println("Stock updated successfully.");
                } else {
                    System.out.println("Failed to update stock.");
                }

                // Close the update PreparedStatement
                updatePst.close();
            } else {
                JOptionPane.showMessageDialog(null, "Out of stock.");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Product not found.");
        }
    } catch (Exception e) {
        // Display any exceptions that occur
        JOptionPane.showMessageDialog(null, e);
    } finally {
        // Close resources
        try {
            if (rs != null) rs.close();
            if (pst != null) pst.close();
            if (con != null) con.close();
        } catch (Exception e) {
            // Display any exceptions that occur
            JOptionPane.showMessageDialog(null, e);
        }
    }

    // Recalculate the total after adding the item
    cal();
    }//GEN-LAST:event_p17ActionPerformed

    private void p18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p18ActionPerformed
        try {
        // Load MySQL JDBC Driver
        Class.forName("com.mysql.cj.jdbc.Driver");

        // Establish connection to the database
        con = DriverManager.getConnection(url, "root", "Admin#01");

        // Prepare SQL query to retrieve product data
        String query = "SELECT Id, Name, price, stock FROM Products WHERE Id = ?";
        pst = con.prepareStatement(query);
        pst.setInt(1, 18);

        // Execute the query and get the result
        rs = pst.executeQuery();

        if (rs.next()) {
            int id = rs.getInt("Id");
            String name = rs.getString("Name");
            double price = rs.getDouble("price");
            int stock = rs.getInt("stock");

            if (stock > 0) {
                // Hide the 'q01' component and show the 'q1' component
                q018.setVisible(false);
                q18.setVisible(true);

                // Get the current value from 'q1', increment it, and update 'q1' with the new value
                int quantity = Integer.valueOf(q18.getText());
                ++quantity;
                q18.setText(String.valueOf(quantity));

                // Add the item to the table with updated quantity
                addtables(id, name, quantity, price);

                // Update the stock level in the database
                String updateQuery = "UPDATE Products SET stock = ? WHERE Id = ?";
                PreparedStatement updatePst = con.prepareStatement(updateQuery);
                updatePst.setInt(1, stock - 1);
                updatePst.setInt(2, id);

                // Execute the update query
                int result = updatePst.executeUpdate();
                if (result > 0) {
                    System.out.println("Stock updated successfully.");
                } else {
                    System.out.println("Failed to update stock.");
                }

                // Close the update PreparedStatement
                updatePst.close();
            } else {
                JOptionPane.showMessageDialog(null, "Out of stock.");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Product not found.");
        }
    } catch (Exception e) {
        // Display any exceptions that occur
        JOptionPane.showMessageDialog(null, e);
    } finally {
        // Close resources
        try {
            if (rs != null) rs.close();
            if (pst != null) pst.close();
            if (con != null) con.close();
        } catch (Exception e) {
            // Display any exceptions that occur
            JOptionPane.showMessageDialog(null, e);
        }
    }

    // Recalculate the total after adding the item
    cal();
    }//GEN-LAST:event_p18ActionPerformed

    private void p19ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p19ActionPerformed
        try {
        // Load MySQL JDBC Driver
        Class.forName("com.mysql.cj.jdbc.Driver");

        // Establish connection to the database
        con = DriverManager.getConnection(url, "root", "Admin#01");

        // Prepare SQL query to retrieve product data
        String query = "SELECT Id, Name, price, stock FROM Products WHERE Id = ?";
        pst = con.prepareStatement(query);
        pst.setInt(1, 19);

        // Execute the query and get the result
        rs = pst.executeQuery();

        if (rs.next()) {
            int id = rs.getInt("Id");
            String name = rs.getString("Name");
            double price = rs.getDouble("price");
            int stock = rs.getInt("stock");

            if (stock > 0) {
                // Hide the 'q01' component and show the 'q1' component
                q019.setVisible(false);
                q19.setVisible(true);

                // Get the current value from 'q1', increment it, and update 'q1' with the new value
                int quantity = Integer.valueOf(q19.getText());
                ++quantity;
                q19.setText(String.valueOf(quantity));

                // Add the item to the table with updated quantity
                addtables(id, name, quantity, price);

                // Update the stock level in the database
                String updateQuery = "UPDATE Products SET stock = ? WHERE Id = ?";
                PreparedStatement updatePst = con.prepareStatement(updateQuery);
                updatePst.setInt(1, stock - 1);
                updatePst.setInt(2, id);

                // Execute the update query
                int result = updatePst.executeUpdate();
                if (result > 0) {
                    System.out.println("Stock updated successfully.");
                } else {
                    System.out.println("Failed to update stock.");
                }

                // Close the update PreparedStatement
                updatePst.close();
            } else {
                JOptionPane.showMessageDialog(null, "Out of stock.");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Product not found.");
        }
    } catch (Exception e) {
        // Display any exceptions that occur
        JOptionPane.showMessageDialog(null, e);
    } finally {
        // Close resources
        try {
            if (rs != null) rs.close();
            if (pst != null) pst.close();
            if (con != null) con.close();
        } catch (Exception e) {
            // Display any exceptions that occur
            JOptionPane.showMessageDialog(null, e);
        }
    }

    // Recalculate the total after adding the item
    cal();
    }//GEN-LAST:event_p19ActionPerformed

    private void p20ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p20ActionPerformed
        try {
        // Load MySQL JDBC Driver
        Class.forName("com.mysql.cj.jdbc.Driver");

        // Establish connection to the database
        con = DriverManager.getConnection(url, "root", "Admin#01");

        // Prepare SQL query to retrieve product data
        String query = "SELECT Id, Name, price, stock FROM Products WHERE Id = ?";
        pst = con.prepareStatement(query);
        pst.setInt(1, 20);

        // Execute the query and get the result
        rs = pst.executeQuery();

        if (rs.next()) {
            int id = rs.getInt("Id");
            String name = rs.getString("Name");
            double price = rs.getDouble("price");
            int stock = rs.getInt("stock");

            if (stock > 0) {
                // Hide the 'q01' component and show the 'q1' component
                q020.setVisible(false);
                q20.setVisible(true);

                // Get the current value from 'q1', increment it, and update 'q1' with the new value
                int quantity = Integer.valueOf(q20.getText());
                ++quantity;
                q20.setText(String.valueOf(quantity));

                // Add the item to the table with updated quantity
                addtables(id, name, quantity, price);

                // Update the stock level in the database
                String updateQuery = "UPDATE Products SET stock = ? WHERE Id = ?";
                PreparedStatement updatePst = con.prepareStatement(updateQuery);
                updatePst.setInt(1, stock - 1);
                updatePst.setInt(2, id);

                // Execute the update query
                int result = updatePst.executeUpdate();
                if (result > 0) {
                    System.out.println("Stock updated successfully.");
                } else {
                    System.out.println("Failed to update stock.");
                }

                // Close the update PreparedStatement
                updatePst.close();
            } else {
                JOptionPane.showMessageDialog(null, "Out of stock.");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Product not found.");
        }
    } catch (Exception e) {
        // Display any exceptions that occur
        JOptionPane.showMessageDialog(null, e);
    } finally {
        // Close resources
        try {
            if (rs != null) rs.close();
            if (pst != null) pst.close();
            if (con != null) con.close();
        } catch (Exception e) {
            // Display any exceptions that occur
            JOptionPane.showMessageDialog(null, e);
        }
    }

    // Recalculate the total after adding the item
    cal();
    }//GEN-LAST:event_p20ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        Login login = new Login();
        login.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        Profile profile = new Profile();
        profile.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButton2ActionPerformed

    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Home().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel backBtn;
    private javax.swing.JLabel bal;
    private javax.swing.JTextArea bill;
    private javax.swing.JPanel billPanel;
    private javax.swing.JButton delete;
    private javax.swing.JPanel displayPanel;
    private javax.swing.JPanel itemsPanel;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton21;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JPanel jPanel;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JPanel listPanel;
    private javax.swing.JLabel nextBtn;
    private javax.swing.JButton p1;
    private javax.swing.JButton p10;
    private javax.swing.JButton p11;
    private javax.swing.JButton p12;
    private javax.swing.JButton p13;
    private javax.swing.JButton p14;
    private javax.swing.JButton p15;
    private javax.swing.JButton p16;
    private javax.swing.JButton p17;
    private javax.swing.JButton p18;
    private javax.swing.JButton p19;
    private javax.swing.JButton p2;
    private javax.swing.JButton p20;
    private javax.swing.JButton p3;
    private javax.swing.JButton p4;
    private javax.swing.JButton p5;
    private javax.swing.JButton p6;
    private javax.swing.JButton p7;
    private javax.swing.JButton p8;
    private javax.swing.JButton p9;
    private javax.swing.JTextField payAmt;
    private javax.swing.JLabel q01;
    private javax.swing.JLabel q010;
    private javax.swing.JLabel q011;
    private javax.swing.JLabel q012;
    private javax.swing.JLabel q013;
    private javax.swing.JLabel q014;
    private javax.swing.JLabel q015;
    private javax.swing.JLabel q016;
    private javax.swing.JLabel q017;
    private javax.swing.JLabel q018;
    private javax.swing.JLabel q019;
    private javax.swing.JLabel q02;
    private javax.swing.JLabel q020;
    private javax.swing.JLabel q03;
    private javax.swing.JLabel q04;
    private javax.swing.JLabel q05;
    private javax.swing.JLabel q06;
    private javax.swing.JLabel q07;
    private javax.swing.JLabel q08;
    private javax.swing.JLabel q09;
    private javax.swing.JLabel q1;
    private javax.swing.JLabel q10;
    private javax.swing.JLabel q11;
    private javax.swing.JLabel q12;
    private javax.swing.JLabel q13;
    private javax.swing.JLabel q14;
    private javax.swing.JLabel q15;
    private javax.swing.JLabel q16;
    private javax.swing.JLabel q17;
    private javax.swing.JLabel q18;
    private javax.swing.JLabel q19;
    private javax.swing.JLabel q2;
    private javax.swing.JLabel q20;
    private javax.swing.JLabel q3;
    private javax.swing.JLabel q4;
    private javax.swing.JLabel q5;
    private javax.swing.JLabel q6;
    private javax.swing.JLabel q7;
    private javax.swing.JLabel q8;
    private javax.swing.JLabel q9;
    private javax.swing.JLabel total;
    // End of variables declaration//GEN-END:variables
}
