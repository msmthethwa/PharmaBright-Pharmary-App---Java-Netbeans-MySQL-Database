/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package pharmabright;

import com.mysql.cj.x.protobuf.MysqlxNotice.Warning.Level;
import java.awt.Color;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.lang.System.Logger;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Arrays;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import java.sql.ResultSet; // For handling SQL query results
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

/**
 *
 * @author MS Mthethwa
 */
public class Admin extends javax.swing.JFrame {

    /**
     * Creates new form Admin
     */
    
    public    Connection con = null;
    public    PreparedStatement pst = null;
    public    ResultSet rs = null;
    
    public String url = "jdbc:mysql://localhost:3306/PharmaBright?zeroDateTimeBehavior=CONVERT_TO_NULL";  
    String path;
    
    public Admin() {
        initComponents();
        this.setExtendedState(JFrame.MAXIMIZED_BOTH);

        // Set preferred width for the first two columns in jTable1
        jTable1.getColumnModel().getColumn(0).setPreferredWidth(30);
        jTable1.getColumnModel().getColumn(1).setPreferredWidth(200);
        
        loadProductData();
    }
    
    private void loadProductData() {
        // Database connection details
        String url = "jdbc:mysql://localhost:3306/PharmaBright";
        String username = "root";
        String password = "Admin#01";
        
        Connection con = null;
        PreparedStatement pst = null;
        ResultSet rs = null;

        try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish connection to the database
            url = "jdbc:mysql://localhost:3306/PharmaBright?zeroDateTimeBehavior=CONVERT_TO_NULL";
            con = DriverManager.getConnection(url, "root", "Admin#01");

            // Prepare SQL query to retrieve product data
            String query = "SELECT Id, Name, stock, price, date_added, image FROM Products";
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();

            // Iterate through the result set and add rows to the table model
            while (rs.next()) {
                String id = rs.getString("Id");
                String name = rs.getString("Name");
                int stock = rs.getInt("stock");
                double price = rs.getDouble("price");
                String dateAdded = rs.getString("date_added");
                byte[] imageBytes = rs.getBytes("image");
                
                // Convert the image bytes to an ImageIcon
                ImageIcon imageIcon = new ImageIcon(new ImageIcon(imageBytes).getImage().getScaledInstance(100, 100, Image.SCALE_DEFAULT));
                
                // Add the data to the table model
                //TableModel.addRow(new Object[]{id, name, stock, price, dateAdded, imageIcon});
                
                // Get the table model from jTable1
                DefaultTableModel dt = (DefaultTableModel) jTable1.getModel();

                // Check if the product is already added and remove it if found
                for (int row = 0; row < jTable1.getRowCount(); row++) {
                    if (name.equals(jTable1.getValueAt(row, 1))) {
                        dt.removeRow(jTable1.convertRowIndexToModel(row));
                    }
                }
                
                // Create an ArrayList to store the row data
                List<Object> row = new ArrayList<>();
                row.add(id);
                row.add(name);
                row.add(stock);
                row.add(price);
                row.add(dateAdded);
                row.add(imageIcon);

                // Add the row to the table model
                dt.addRow(row.toArray());
            }
        } catch (Exception e) {
                // Display any exceptions that occur
                JOptionPane.showMessageDialog(null, e);
        } finally {
            // Close resources
            try {
                if (rs != null) rs.close();
                if (pst != null) pst.close();
                if (con != null) con.close();
            } catch (Exception e) {
                // Display any exceptions that occur
                JOptionPane.showMessageDialog(null, e);
            }
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jButton2 = new javax.swing.JButton();
        uploadPanel = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        proName = new javax.swing.JTextField();
        proID = new javax.swing.JTextField();
        stockLevel = new javax.swing.JTextField();
        Date = new javax.swing.JTextField();
        Price = new javax.swing.JTextField();
        image = new javax.swing.JLabel();
        browse = new javax.swing.JButton();
        jButton21 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        displayPanel = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton22 = new javax.swing.JButton();
        editProduct = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton2.setBackground(new java.awt.Color(0, 153, 153));
        jButton2.setForeground(new java.awt.Color(255, 255, 204));
        jButton2.setText("Profile");
        jButton2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 20, 100, -1));

        uploadPanel.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        uploadPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel4.setBackground(new java.awt.Color(0, 0, 0));
        jLabel4.setFont(new java.awt.Font("Myanmar Text", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 153, 153));
        jLabel4.setText("Product Name");
        uploadPanel.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 150, -1, -1));

        jLabel5.setBackground(new java.awt.Color(0, 0, 0));
        jLabel5.setFont(new java.awt.Font("Myanmar Text", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 153, 153));
        jLabel5.setText("Product ID");
        uploadPanel.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 80, -1, -1));

        jLabel6.setBackground(new java.awt.Color(0, 0, 0));
        jLabel6.setFont(new java.awt.Font("Myanmar Text", 1, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 153, 153));
        jLabel6.setText("Date");
        uploadPanel.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 340, -1, -1));

        jLabel7.setBackground(new java.awt.Color(0, 0, 0));
        jLabel7.setFont(new java.awt.Font("Myanmar Text", 1, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 153, 153));
        jLabel7.setText("Stock Level");
        uploadPanel.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 220, -1, -1));

        jLabel8.setBackground(new java.awt.Color(0, 0, 0));
        jLabel8.setFont(new java.awt.Font("Myanmar Text", 1, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 153, 153));
        jLabel8.setText("Price");
        uploadPanel.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 290, -1, -1));

        proName.setFont(new java.awt.Font("Myanmar Text", 3, 14)); // NOI18N
        proName.setForeground(new java.awt.Color(0, 0, 0));
        proName.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 153, 153), 3));
        uploadPanel.add(proName, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 140, 380, 40));

        proID.setFont(new java.awt.Font("Myanmar Text", 3, 14)); // NOI18N
        proID.setForeground(new java.awt.Color(0, 0, 0));
        proID.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 153, 153), 3));
        proID.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                proIDKeyTyped(evt);
            }
        });
        uploadPanel.add(proID, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 70, 380, 40));

        stockLevel.setFont(new java.awt.Font("Myanmar Text", 3, 14)); // NOI18N
        stockLevel.setForeground(new java.awt.Color(204, 204, 204));
        stockLevel.setText("0");
        stockLevel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 153, 153), 3));
        stockLevel.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                stockLevelFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                stockLevelFocusLost(evt);
            }
        });
        stockLevel.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                stockLevelKeyTyped(evt);
            }
        });
        uploadPanel.add(stockLevel, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 210, 380, 40));

        Date.setFont(new java.awt.Font("Myanmar Text", 3, 14)); // NOI18N
        Date.setForeground(new java.awt.Color(204, 204, 204));
        Date.setText("dd/mm/yyyy");
        Date.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 153, 153), 3));
        Date.setName(""); // NOI18N
        Date.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                DateFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                DateFocusLost(evt);
            }
        });
        Date.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                DateKeyTyped(evt);
            }
        });
        uploadPanel.add(Date, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 340, 380, 40));

        Price.setFont(new java.awt.Font("Myanmar Text", 3, 14)); // NOI18N
        Price.setForeground(new java.awt.Color(204, 204, 204));
        Price.setText("0.00");
        Price.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 153, 153), 3));
        Price.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                PriceFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                PriceFocusLost(evt);
            }
        });
        Price.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                PriceKeyTyped(evt);
            }
        });
        uploadPanel.add(Price, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 280, 380, 40));

        image.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        image.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
        uploadPanel.add(image, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 390, 130, 120));

        browse.setBackground(new java.awt.Color(0, 153, 153));
        browse.setForeground(new java.awt.Color(255, 255, 204));
        browse.setText("Add Image");
        browse.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        browse.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                browseActionPerformed(evt);
            }
        });
        uploadPanel.add(browse, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 510, 100, -1));

        jButton21.setBackground(new java.awt.Color(0, 153, 153));
        jButton21.setFont(new java.awt.Font("Myanmar Text", 3, 18)); // NOI18N
        jButton21.setForeground(new java.awt.Color(255, 255, 255));
        jButton21.setText("Upload product");
        jButton21.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton21.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton21.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton21ActionPerformed(evt);
            }
        });
        uploadPanel.add(jButton21, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 440, 180, 40));

        jLabel2.setBackground(new java.awt.Color(0, 0, 0));
        jLabel2.setFont(new java.awt.Font("Elephant", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 0));
        jLabel2.setText("Product Upload");
        uploadPanel.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 20, -1, -1));

        jPanel1.add(uploadPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 80, 610, 550));

        jLabel3.setBackground(new java.awt.Color(0, 0, 0));
        jLabel3.setFont(new java.awt.Font("Elephant", 1, 36)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 153, 153));
        jLabel3.setText("PharmaBright Pharmacy");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 10, -1, -1));

        displayPanel.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        displayPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Product Name", "Stock Level", "Price", "Date ", "Image ID"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        displayPanel.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 600, 500));

        jButton22.setBackground(new java.awt.Color(102, 0, 0));
        jButton22.setFont(new java.awt.Font("Myanmar Text", 3, 14)); // NOI18N
        jButton22.setForeground(new java.awt.Color(255, 255, 255));
        jButton22.setText("Delete ");
        jButton22.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton22.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton22.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton22ActionPerformed(evt);
            }
        });
        displayPanel.add(jButton22, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 510, 90, 30));

        editProduct.setBackground(new java.awt.Color(0, 0, 102));
        editProduct.setFont(new java.awt.Font("Myanmar Text", 3, 14)); // NOI18N
        editProduct.setForeground(new java.awt.Color(255, 255, 255));
        editProduct.setText("Edit");
        editProduct.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        editProduct.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        editProduct.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editProductActionPerformed(evt);
            }
        });
        displayPanel.add(editProduct, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 510, 90, 30));

        jPanel1.add(displayPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 80, 600, 550));

        jButton3.setBackground(new java.awt.Color(0, 153, 153));
        jButton3.setForeground(new java.awt.Color(255, 255, 204));
        jButton3.setText("Home");
        jButton3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 20, 100, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 1320, 670));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Bg3.jpg"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1370, 770));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void PriceKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_PriceKeyTyped
        // TODO add your handling code here:
        // Get the typed character
        char c = evt.getKeyChar();

        // Allow only digits and one dot
        if (!Character.isDigit(c) && c != '.') {
            // Consume the event to prevent non-digit and non-dot characters from being entered
            evt.consume();
        } else if (c == '.' && Price.getText().contains(".")) {
            // If a dot is already present, consume the event to prevent multiple dots
            evt.consume();
        }
    }//GEN-LAST:event_PriceKeyTyped

    private void DateKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_DateKeyTyped
        // Get the typed character
        char c = evt.getKeyChar();

        // Get the current text in the Date field
        String currentText = Date.getText();

        // Allow only digits and slashes, ensure there are only two slashes, and limit length to 10 characters
        if (!Character.isDigit(c) && c != '/') {
            // Consume the event to prevent non-digit and non-slash characters from being entered
            evt.consume();
        } else if (c == '/' && currentText.chars().filter(ch -> ch == '/').count() >= 2) {
            // If two slashes are already present, consume the event to prevent additional slashes
            evt.consume();
        } else if (currentText.length() >= 10) {
            // If the length of the text is already 10 characters, consume the event to prevent further input
            evt.consume();
        }
    }//GEN-LAST:event_DateKeyTyped

    private void PriceFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_PriceFocusGained
        // TODO add your handling code here:
        if(Price.getText().equals("0.00")){
            Price.setText("");
            Price.setForeground(new Color (0,0,0));
        }
    }//GEN-LAST:event_PriceFocusGained

    private void PriceFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_PriceFocusLost
        // TODO add your handling code here:
        if(Price.getText().equals("")){
            Price.setText("0.00");
            Price.setForeground(new Color (204,204,204));
        }
    }//GEN-LAST:event_PriceFocusLost

    private void DateFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_DateFocusGained
        // TODO add your handling code here:
        if(Date.getText().equals("dd/mm/yyyy")){
            Date.setText("");
            Date.setForeground(new Color (0,0,0));
        }
    }//GEN-LAST:event_DateFocusGained

    private void DateFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_DateFocusLost
        // TODO add your handling code here:
        if(Date.getText().equals("")){
            Date.setText("dd/mm/yyyy");
            Date.setForeground(new Color (204,204,204));
        }
    }//GEN-LAST:event_DateFocusLost

    private void stockLevelKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_stockLevelKeyTyped
        // Get the typed character
        char c = evt.getKeyChar();

        // Check if the character is not a digit
        if (!Character.isDigit(c)) {
            // Consume the event to prevent non-digit characters from being entered
            evt.consume();
        }
    }//GEN-LAST:event_stockLevelKeyTyped

    private void stockLevelFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_stockLevelFocusGained
        // TODO add your handling code here:
        if(stockLevel.getText().equals("0")){
            stockLevel.setText("");
            stockLevel.setForeground(new Color (0,0,0));
        }
    }//GEN-LAST:event_stockLevelFocusGained

    private void stockLevelFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_stockLevelFocusLost
        // TODO add your handling code here:
        if(stockLevel.getText().equals("")){
            stockLevel.setText("0");
            stockLevel.setForeground(new Color (204,204,204));
        }
    }//GEN-LAST:event_stockLevelFocusLost

    private void jButton21ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton21ActionPerformed
        // Retrieve user input from text fields and password fields
        String id = proID.getText();
        String name = proName.getText();
        String level = stockLevel.getText();
        String price = Price.getText();
        String date = Date.getText();

        // Input validation
        if (id.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Enter Product ID");
        } else if (name.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Enter Product Name");
        } else if (level.isEmpty() || level.equals("0")) {
            JOptionPane.showMessageDialog(null, "Enter Stock Level");
        } else if (price.isEmpty() || price.equals("0.00")) {
            JOptionPane.showMessageDialog(null, "Enter Product Price");
        } else if (date.isEmpty() || date.equals("dd/mm/yyyy")) {
            JOptionPane.showMessageDialog(null, "Enter Date");
        } else {
            try {
                // Load MySQL JDBC Driver
                Class.forName("com.mysql.cj.jdbc.Driver");

                // Establish connection to the database
                String URL = "jdbc:mysql://localhost:3306/PharmaBright?zeroDateTimeBehavior=CONVERT_TO_NULL";
                Connection con = DriverManager.getConnection(URL, "root", "Admin#01");

                try {
                    InputStream is = new FileInputStream(new File(path));

                    // Prepare SQL query to insert product data
                    String query = "INSERT INTO Products (Id, Name, stock, price, date_added, image) VALUES (?, ?, ?, ?, ?, ?)";
                    PreparedStatement pst = con.prepareStatement(query);
                    pst.setString(1, id); // Set product ID
                    pst.setString(2, name); // Set product name
                    pst.setInt(3, Integer.parseInt(level)); // Set stock level
                    pst.setBigDecimal(4, new BigDecimal(price)); // Set price
                    pst.setString(5, date); // Set date
                    pst.setBlob(6, is); // Set image

                    // Execute the query and get the result
                    int result = pst.executeUpdate();
                    if (result > 0) {
                        //JOptionPane.showMessageDialog(null, "Product added successfully.");
                        proID.setText(null);
                        proName.setText(null);
                        stockLevel.setText(null);
                        Price.setText(null);
                        Date.setText(null);
                        image.setIcon(null);
                    } else {
                        JOptionPane.showMessageDialog(null, "Product addition failed. Please try again.");
                    }

                    // Close resources
                    pst.close();
                    con.close();

                } catch (FileNotFoundException ex) {
                    java.util.logging.Logger.getLogger(Admin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
                }
            } catch (Exception e) {
                // Display any exceptions that occur
                JOptionPane.showMessageDialog(null, e);
            }
        }
        
        loadProductData();
    }//GEN-LAST:event_jButton21ActionPerformed

    private void proIDKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_proIDKeyTyped
        // TODO add your handling code here:
        // Get the typed character
        char c = evt.getKeyChar();

        // Check if the character is not a digit
        if (!Character.isDigit(c)) {
            // Consume the event to prevent non-digit characters from being entered
            evt.consume();
        }
    }//GEN-LAST:event_proIDKeyTyped

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        Home home = new Home();
        home.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButton3ActionPerformed

    private void browseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_browseActionPerformed
        // TODO add your handling code here:
        JFileChooser jf = new JFileChooser () ;
        jf.showOpenDialog (null);
        File f = jf.getSelectedFile();
        path = f.getAbsolutePath();
        try{
           BufferedImage bi = ImageIO.read(new File (path));
           Image img = bi.getScaledInstance (100,100, Image.SCALE_SMOOTH);
           ImageIcon i = new ImageIcon (img) ;
           image.setIcon(i);
        } catch (Exception e) {
                // Display any exceptions that occur
                JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_browseActionPerformed

    private void jButton22ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton22ActionPerformed
        // Get the table model from jTable1
        DefaultTableModel dt = (DefaultTableModel) jTable1.getModel();

        // Get the index of the selected row
        int selectedRow = jTable1.getSelectedRow();

        if (selectedRow == -1) {
            // No row is selected, show error message
            JOptionPane.showMessageDialog(this, "Please select a row", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            // A row is selected, proceed with deletion
            String id = dt.getValueAt(selectedRow, 0).toString(); // Get the value of the first column (ID) of the selected row

            // Confirm deletion with the user
            int option = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete this product?", "Delete Product", JOptionPane.YES_NO_OPTION);
            if (option == JOptionPane.YES_OPTION) {
                // Remove the selected row from the table model
                dt.removeRow(selectedRow);

                // Database connection details
                String url = "jdbc:mysql://localhost:3306/PharmaBright";
                String username = "root";
                String password = "Admin#01";

                Connection con = null;
                PreparedStatement pst = null;

                try {
                    // Load the MySQL JDBC driver
                    Class.forName("com.mysql.cj.jdbc.Driver");

                    // Establish connection
                    con = DriverManager.getConnection(url, username, password);

                    // Prepare SQL query to delete the product data
                    String query = "DELETE FROM Products WHERE Id = ?";
                    pst = con.prepareStatement(query);
                    pst.setString(1, id);

                    // Execute the delete query
                    int result = pst.executeUpdate();
                    if (result > 0) {
                        //JOptionPane.showMessageDialog(null, "Product deleted successfully.");
                    } else {
                        JOptionPane.showMessageDialog(null, "Failed to delete product. Please try again.");
                    }

                } catch (Exception e) {
                // Display any exceptions that occur
                JOptionPane.showMessageDialog(null, e);
            }finally {
                    // Close resources to avoid memory leaks
                    try {
                        if (pst != null) pst.close();
                        if (con != null) con.close();
                    }catch (Exception e) {
                        // Display any exceptions that occur
                        JOptionPane.showMessageDialog(null, e);
                    }
                }
            }
        }
    }//GEN-LAST:event_jButton22ActionPerformed

    private void editProductActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editProductActionPerformed
        // TODO add your handling code here:
        // Get the table model from jTable1
        DefaultTableModel dt = (DefaultTableModel) jTable1.getModel();

        // Get the index of the selected row
        int selectedRow = jTable1.getSelectedRow();

        if (selectedRow == -1) {
            // No row is selected, show error message
            JOptionPane.showMessageDialog(this, "Please select a row", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            // A row is selected, proceed with editing
            String id = dt.getValueAt(selectedRow, 0).toString(); // Get the value of the first column (ID) of the selected row
            String name = dt.getValueAt(selectedRow, 1).toString();
            String stock = dt.getValueAt(selectedRow, 2).toString();
            String price = dt.getValueAt(selectedRow, 3).toString();
            String dateAdded = dt.getValueAt(selectedRow, 4).toString();

            // Prompt the user to edit the product details
            JTextField idField = new JTextField(id);
            idField.setEditable(false); // ID should not be editable
            JTextField nameField = new JTextField(name);
            JTextField stockField = new JTextField(stock);
            JTextField priceField = new JTextField(price);
            JTextField dateField = new JTextField(dateAdded);

            Object[] message = {
                "ID:", idField,
                "Name:", nameField,
                "Stock:", stockField,
                "Price:", priceField,
                "Date Added:", dateField
            };

            int option = JOptionPane.showConfirmDialog(null, message, "Edit Product", JOptionPane.OK_CANCEL_OPTION);
            if (option == JOptionPane.OK_OPTION) {
                // Update the table model with the new values
                dt.setValueAt(nameField.getText(), selectedRow, 1);
                dt.setValueAt(stockField.getText(), selectedRow, 2);
                dt.setValueAt(priceField.getText(), selectedRow, 3);
                dt.setValueAt(dateField.getText(), selectedRow, 4);

                try {
                    // Load MySQL JDBC Driver
                    Class.forName("com.mysql.cj.jdbc.Driver");

                    // Establish connection to the database
                    con = DriverManager.getConnection(url, "root", "Admin#01");

                    // Prepare SQL query to update the product data
                    String query = "UPDATE Products SET Name = ?, stock = ?, price = ?, date_added = ? WHERE Id = ?";
                    pst = con.prepareStatement(query);
                    pst.setString(1, nameField.getText());
                    pst.setInt(2, Integer.parseInt(stockField.getText()));
                    pst.setDouble(3, Double.parseDouble(priceField.getText()));
                    pst.setString(4, dateField.getText());
                    pst.setString(5, id);

                    // Execute the update query
                    int result = pst.executeUpdate();
                    if (result > 0) {
                        //JOptionPane.showMessageDialog(null, "Product updated successfully.");
                    } else {
                        JOptionPane.showMessageDialog(null, "Failed to update product. Please try again.");
                    }

                } catch (Exception e) {
                    // Display any exceptions that occur
                    JOptionPane.showMessageDialog(null, e);
                } finally {
                    // Close resources to avoid memory leaks
                    try {
                        if (pst != null) pst.close();
                        if (con != null) con.close();
                    } catch (Exception e) {
                        // Display any exceptions that occur
                        JOptionPane.showMessageDialog(null, e);
                    }
                }
            }
        }
    }//GEN-LAST:event_editProductActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        Profile profile = new Profile();
        profile.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButton2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Admin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Admin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Admin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Admin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Admin().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Date;
    private javax.swing.JTextField Price;
    private javax.swing.JButton browse;
    private javax.swing.JPanel displayPanel;
    private javax.swing.JButton editProduct;
    private javax.swing.JLabel image;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton21;
    private javax.swing.JButton jButton22;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField proID;
    private javax.swing.JTextField proName;
    private javax.swing.JTextField stockLevel;
    private javax.swing.JPanel uploadPanel;
    // End of variables declaration//GEN-END:variables
}
